# 手串4类素材排布&绘制改造计划

## 任务理解

将手串素材从当前"统一圆珠"模型改造为4种类型（bead/spacer/ornament/pendant），每种类型有独立的排布规则和绘制方式，同时保留透明底、真实比例，不破坏现有拖拽/删除/保存功能。

## 当前状态分析

- **框架**: 微信小程序原生（WXML + WXSS + JS）
- **实时预览**: WXML 视图层（`<view>` + CSS `position: absolute`），非 Canvas 实时渲染
- **Canvas 用途**: 仅在保存/下单时生成 300x300 缩略图
- **当前类型**: `bead`/`spacer`/`pendant`/`accessory`（accessory 需改名为 ornament）
- **当前布局**: `computeBeadPositions()` 所有素材统一按 `beadPx` 紧密排列在圆环上
- **素材数据**: 缺少 `trackLen`/`imgW`/`imgH` 字段

## 改造方案

### 第1步：统一素材字段 & 类型重命名

**文件**: `miniprogram/utils/util.js`
- `MATERIAL_TYPES` 中 `accessory` → `ornament`，标签改为"配饰"

**文件**: `miniprogram/pages/admin/material-edit/material-edit.js` + `.wxml`
- `typeOptions` 中 `accessory` → `ornament`
- 新增3个输入字段：`trackLen`（轨道占用长度mm）、`imgW`（图片宽px）、`imgH`（图片高px）
- 保存时将这3个字段存入 `specs` 对象：`specs.trackLen`、`specs.imgW`、`specs.imgH`
- 不同类型显示不同默认值和提示：
  - bead: trackLen = size(直径), imgW/imgH 可选填
  - spacer: trackLen 默认2mm, imgW/imgH 可选填
  - ornament: trackLen = size, imgW/imgH 建议填写
  - pendant: trackLen 默认0(不占轨道), imgW/imgH 建议填写

**文件**: `cloudfunctions/initData/index.js`
- 分类中 `accessory` → `ornament`
- 示例素材中 `type: 'accessory'` → `type: 'ornament'`

### 第2步：改造 computeBeadPositions() 布局算法

**文件**: `miniprogram/pages/design/design.js` 第128-200行

核心逻辑变更：

```
1. 遍历 bracelet 数组，分3组：
   - ringBeads: type 为 bead/spacer/ornament 的有素材珠子（参与圆环排列）
   - pendants: type 为 pendant 的有素材珠子（不参与圆环，固定底部）
   - 空位跳过

2. 计算圆环半径：
   - ringBeads 的总 trackLen(mm) × PX_PER_MM = 总弧长(px)
   - 封闭圆判定不变（>120mm 紧缩）
   - ringRadius = 总弧长 / (2π) 或基于手围

3. 圆环排列 ringBeads：
   - 弧长累加排列，每颗珠子的弧长占用 = trackLen(mm) × PX_PER_MM
   - bead: size = trackLen × PX_PER_MM（正方形区域，图片 aspectFit 居中）
   - spacer: size = trackLen × PX_PER_MM（很小，如2mm=8px），保持透明异形
   - ornament: size = trackLen × PX_PER_MM，但绘制时按 imgW/imgH 真实比例

4. 吊坠 pendant 定位：
   - 固定在圆环最底部（12点钟方向的对面，即 angle = π/2）
   - x = centerX - pendantWidth/2, y = centerY + ringRadius（紧贴圆环外侧底部）
   - 垂直下垂，不旋转

5. positions 数组新增字段：
   - width / height（区分宽高，ornament 可能不等）
   - isPendant: boolean
   - drawWidth / drawHeight（实际绘制尺寸）
```

### 第3步：改造 WXML 实时预览模板

**文件**: `miniprogram/pages/design/design.wxml` 第38-54行

- 珠子 `<view>` 的 width/height 改为使用 `beadPositions[index].width` 和 `beadPositions[index].height`（支持不等宽高）
- 吊坠单独渲染或通过条件判断：
  - 非 pendant: 保持现有 `rotate` 逻辑
  - pendant: 不旋转，固定底部居中
- 图片 `<image>` 的 mode 统一用 `aspectFit`（保持透明底和真实比例）
- 移除 `bead-color-fill` 对非 bead 类型的强制圆形裁剪

### 第4步：改造 WXSS 样式

**文件**: `miniprogram/pages/design/design.wxss`

- `.bead-dot` 默认 `background: transparent`（已满足）
- `.bead-image` 不加 `border-radius`（已满足，当前无 border-radius）
- `.bead-color-fill` 仅对 bead 类型生效（通过 WXML 条件判断）
- 新增 `.bead-ornament` 样式类：保持透明底，按真实比例显示
- 新增 `.bead-pendant` 样式类：不旋转，垂直悬挂效果

### 第5步：改造 Canvas 缩略图绘制

**文件**: `miniprogram/pages/design/design.js` 第939-1068行 `_generatePreviewImage()`

绘制逻辑变更：

```
1. 先画手串线（圆环）
2. 遍历 ringBeads（bead/spacer/ornament）：
   - bead: 按正方形区域 aspectFit 绘制图片，或画颜色圆
   - spacer: 按小区域 aspectFit 绘制异形透明图
   - ornament: 按 imgW/imgH 真实比例绘制，随轨道角度旋转
3. 最后画 pendant：
   - 定位在圆环底部居中
   - 按 imgW/imgH 真实比例绘制，不旋转
4. 所有绘制不填充白色背景，不裁圆
```

### 第6步：改造素材添加逻辑 onTapMaterial()

**文件**: `miniprogram/pages/design/design.js` 第493-573行

- 添加素材时，从 `material.specs` 读取 `trackLen`/`imgW`/`imgH`
- 存入 bracelet 数组的新字段：`trackLen`、`imgW`、`imgH`
- 手围超限判断改用 `trackLen` 而非 `beadMm`（pendant 的 trackLen=0 不占手围）
- `beadPx` 计算逻辑改为：`trackLen × PX_PER_MM`（如果 trackLen 存在）

### 第7步：改造拖拽换位逻辑

**文件**: `miniprogram/pages/design/design.js` 第683-849行

- 拖拽时 pendant 类型不允许拖入圆环位置（或允许但自动归位到底部）
- 弧长换位算法 `_findDropIndexByArc` 中，pendant 不参与弧长计算
- 拖拽 pendant 时可以拖到垃圾桶删除，但松手在画布上时回到原位

### 第8步：素材管理后台适配

**文件**: `miniprogram/pages/admin/material-edit/material-edit.wxml` + `.js`

- 表单新增3个字段（trackLen / imgW / imgH），根据 type 显示不同提示
- type 切换时自动填充默认值：
  - bead → trackLen = size值, imgW/imgH 清空
  - spacer → trackLen = 2, imgW/imgH 清空
  - ornament → trackLen = size值, imgW/imgH 清空
  - pendant → trackLen = 0, imgW/imgH 清空

## 素材管理设置指南

用户在素材管理后台添加素材时：

| 类型 | trackLen | imgW | imgH | 说明 |
|------|----------|------|------|------|
| 圆珠 bead | 填珠子直径(mm)，如8 | 可不填 | 可不填 | trackLen当直径，图片透明底不裁圆 |
| 隔片 spacer | 填很小值，如2 | 可不填 | 可不填 | 只占窄间距，保持异形透明 |
| 配饰 ornament | 填占用轨道长度(mm) | 建议填图片实际宽px | 建议填图片实际高px | 按真实比例绘制，随轨道旋转 |
| 吊坠 pendant | 填0（不占轨道） | 建议填图片实际宽px | 建议填图片实际高px | 固定底部居中悬挂 |

## 不变的部分

- 拖拽功能（touchstart/move/end 事件处理）
- 垃圾桶删除功能
- 保存设计功能（缩略图生成 + 云函数保存）
- 双指缩放、自动旋转
- 手围选择、价格计算
- 素材搜索、分类筛选、尺寸筛选

## 验证步骤

1. 添加 bead 类型素材 → 验证圆环排列、透明底、不裁圆
2. 添加 spacer 类型素材 → 验证窄间距、异形透明、夹在珠子中间
3. 添加 ornament 类型素材 → 验证按真实比例绘制、随轨道旋转
4. 添加 pendant 类型素材 → 验证固定底部居中、不占轨道、垂直下垂
5. 拖拽 bead/spacer/ornament 换位 → 验证弧长精准换位
6. 拖拽 pendant → 验证不参与圆环换位、可删除
7. 保存设计 → 验证缩略图中4种类型都正确绘制
8. 素材管理后台 → 验证新增字段的保存和回显
