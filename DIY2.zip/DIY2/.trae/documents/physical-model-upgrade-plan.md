# 素材物理模型升级计划

## 任务理解

将手串渲染从"图片拼贴"升级为"物理穿戴"模型。核心变化：
- 布局由**物理尺寸**驱动（外径/厚度），不再依赖图片像素
- 圆柱类配件（隔片等）穿孔在侧面，需要**向外偏移**（图片中心 ≠ 圆环点）
- 吊坠需要**悬挂在线上**（加挂线，贴图在线下方）
- 图片只是**贴图**，不是布局依据

## 当前问题诊断

| 问题 | 当前代码 | 应该是 |
|------|---------|--------|
| 布局依据 | `trackLen` + 图片 `imgW/imgH` 混合驱动 | 纯物理尺寸：外径(outerD)、厚度(thickness) |
| 圆柱偏移 | 所有类型图片中心 = 圆环上的点 | 圆柱类：穿孔点在圆环上，图片向外偏移半个厚度 |
| 吊坠定位 | `y = attachY`（贴在圆上） | 需要挂线 + 吊坠在线下方 |
| 尺寸计算 | 部分用 `imgW/imgH` 像素值 | 全部用 `mm × PX_PER_MM` |

## 新素材物理模型

### specs 字段定义

```javascript
// 所有类型通用
outerD: 10,      // 外径(mm)，圆珠=直径，圆柱=外径，异形=最大跨度
thickness: 10,   // 厚度(mm)，珠子穿线方向的尺寸（= trackLen）

// 仅吊坠
hangLength: 8,   // 挂线长度(mm)，从圆环到吊坠顶部的距离
```

### 各类型物理参数

| 类型 | outerD | thickness | trackLen | 说明 |
|------|--------|-----------|----------|------|
| 圆珠 bead | 10(直径) | 10 | = outerD | 球体，各方向等大 |
| 隔片 spacer | 10(外径) | 2(薄) | = thickness | 圆柱，穿孔在侧面 |
| 配饰 ornament | 12(最大跨度) | 8 | = thickness | 不规则，按厚度占轨道 |
| 吊坠 pendant | 15(宽) | - | 0 | 不占轨道，挂在线上 |

### 渲染逻辑

```
圆珠：图片中心 = 圆环点，显示尺寸 = outerD × PX_PER_MM（正方形区域）
隔片：穿孔点在圆环上，图片沿法线向外偏移 (outerD - thickness) / 2
       显示尺寸：切线方向 = outerD × PX_PER_MM，法线方向 = thickness × PX_PER_MM
配饰：图片中心 = 圆环点，显示尺寸 = outerD × PX_PER_MM（正方形区域）
吊坠：挂线从圆环底部向下延伸 hangLength，吊坠在挂线下方
```

## 改造步骤

### 第1步：升级素材管理后台表单

**文件：** `material-edit.js` + `material-edit.wxml`

- 删除旧字段：`trackLen`、`imgW`、`imgH`
- 新增字段：`outerD`（外径mm）、`thickness`（厚度mm）、`hangLength`（挂线长度mm，仅吊坠）
- `size` 字段保留（作为 outerD 的快捷填入）
- 类型切换时自动填充默认值：
  - bead → outerD = size值, thickness = size值
  - spacer → outerD = size值, thickness = 2
  - ornament → outerD = size值, thickness = size值
  - pendant → outerD = size值, hangLength = 8
- 保存时存入 `specs.outerD`、`specs.thickness`、`specs.hangLength`

### 第2步：升级 design.js 数据模型

**文件：** `design.js`

- `onTapMaterial()` 中从 `material.specs` 读取 `outerD`、`thickness`、`hangLength`
- bracelet 数组元素新增字段：`outerD`、`thickness`、`hangLength`
- `trackLen` 改为 `= thickness`（穿线方向尺寸 = 轨道占用）
- 删除 `imgW`、`imgH` 的读取和使用

### 第3步：重写 computeBeadPositions() 布局算法

**文件：** `design.js` 第128-300行

核心变更：

```
1. trackLen 全部改为 thickness（穿线方向尺寸）
2. 圆珠 bead：
   - 穿孔点在圆环上
   - 图片中心 = 穿孔点（不偏移）
   - 显示区域 = outerD × PX_PER_MM（正方形）
3. 隔片 spacer：
   - 穿孔点在圆环上
   - 图片沿法线方向向外偏移 offset = (outerD - thickness) / 2 × PX_PER_MM
   - 显示区域：切线方向 = outerD × PX_PER_MM，法线方向 = outerD × PX_PER_MM
   - 旋转角度 = 沿切线方向
4. 配饰 ornament：
   - 穿孔点在圆环上
   - 图片中心 = 穿孔点（不偏移）
   - 显示区域 = outerD × PX_PER_MM（正方形）
5. 吊坠 pendant：
   - 挂线起点 = 圆环底部
   - 挂线长度 = hangLength × PX_PER_MM
   - 吊坠顶部 = 挂线起点 + 挂线长度
   - 吊坠显示区域 = outerD × PX_PER_MM（正方形）
```

### 第4步：升级 WXML 模板

**文件：** `design.wxml`

- 吊坠区域：添加挂线 `<view>` 元素（从圆环底部到吊坠顶部）
- 隔片：通过 `offsetX`/`offsetY` 实现向外偏移
- 图片统一用 `mode="aspectFit"`，显示尺寸由物理参数决定

### 第5步：升级 Canvas 缩略图绘制

**文件：** `design.js` `_generatePreviewImage()`

- 隔片绘制时添加偏移
- 吊坠绘制时先画挂线再画吊坠图片
- 所有尺寸使用物理参数计算

### 第6步：升级拖拽和周长计算

**文件：** `design.js`

- `calcBeadTotalMm()`：使用 `thickness` 替代 `trackLen`
- `_findDropIndexByArc()`：使用 `thickness` 计算弧长
- `onTapMaterial()` 超限判断：使用 `thickness`

## 不变的部分

- 拖拽功能（touchstart/move/end）
- 垃圾桶删除
- 保存设计
- 双指缩放
- 自动旋转
- 素材搜索/分类筛选

## 验证步骤

1. 添加 10mm 圆珠 + 8mm 隔片 → 隔片视觉上比圆珠小，隔片向外偏移
2. 添加吊坠 → 吊坠通过挂线悬挂在圆环下方
3. 保存设计 → 缩略图正确显示偏移和挂线
4. 拖拽换位 → 功能正常
5. 素材管理后台 → 新字段正确保存和回显
