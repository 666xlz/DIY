# 滑动画布旋转手串功能计划

## 任务理解

在现有手串设计页面中，添加单指滑动画布旋转手串的功能。当前已有双指缩放功能，需要扩展为：
- 单指滑动 = 旋转手串
- 双指 = 缩放（已有功能保留）

## 当前状态分析

**已有功能：**
- `rotation` 数据字段：控制手串旋转角度（弧度）
- `computeBeadPositions()`：根据 rotation 重新计算珠子位置
- `onTouchStartRotate` / `onTouchMoveRotate` / `onTouchEndRotate`：处理双指缩放
- 左右旋转按钮：`onRotateLeft` / `onRotateRight`
- 自动旋转：`toggleAutoRotate`

**关键文件：**
- `miniprogram/pages/design/design.js`：触摸事件和旋转逻辑
- `miniprogram/pages/design/design.wxml`：画布容器 `.preview-ring` 已绑定 touch 事件

## 改造方案

### 第1步：修改触摸事件处理逻辑

**文件：** `miniprogram/pages/design/design.js`

**修改 `onTouchStartRotate`：**
- 区分单指和双指触摸
- 单指：记录起始角度（通过 atan2 计算手指相对于圆心的角度）
- 双指：保持原有缩放逻辑

```javascript
onTouchStartRotate(e) {
  if (e.touches.length === 1) {
    // 单指：准备旋转
    const touch = e.touches[0]
    const rect = this._ringRect
    if (!rect) return
    
    const scale = this.data.canvasScale
    const relX = (touch.clientX - rect.left) / scale
    const relY = (touch.clientY - rect.top) / scale
    const cx = this.data.ringRadius + 40
    const cy = this.data.ringRadius + 40
    
    this._rotateStartAngle = Math.atan2(relY - cy, relX - cx)
    this._rotateBaseRotation = this.data.rotation
    this._touchMode = 'rotate'
  } else if (e.touches.length >= 2) {
    // 双指：保持原有缩放逻辑
    // ... existing code
  }
}
```

**修改 `onTouchMoveRotate`：**
- 单指移动：计算角度差，更新 rotation
- 双指移动：保持原有缩放逻辑

```javascript
onTouchMoveRotate(e) {
  if (this._touchMode === 'rotate' && e.touches.length === 1) {
    // 单指旋转
    const touch = e.touches[0]
    const rect = this._ringRect
    if (!rect) return
    
    const scale = this.data.canvasScale
    const relX = (touch.clientX - rect.left) / scale
    const relY = (touch.clientY - rect.top) / scale
    const cx = this.data.ringRadius + 40
    const cy = this.data.ringRadius + 40
    
    const currentAngle = Math.atan2(relY - cy, relX - cx)
    const angleDiff = currentAngle - this._rotateStartAngle
    
    this.setData({ rotation: this._rotateBaseRotation + angleDiff })
    this.computeBeadPositions()
  } else if (e.touches.length >= 2) {
    // 双指缩放：保持原有逻辑
    // ... existing code
  }
}
```

**修改 `onTouchEndRotate`：**
- 清理旋转相关临时变量

```javascript
onTouchEndRotate() {
  this._touchMode = undefined
  this._pinchStartDist = undefined
  this._rotateStartAngle = undefined
  this._rotateBaseRotation = undefined
  wx.nextTick(() => {
    this._updateRingRect()
    this._updateTrashRect()
  })
}
```

### 第2步：处理与拖拽珠子的冲突

**问题：** 单指滑动画布旋转 与 单指拖拽珠子 可能冲突

**解决方案：**
- 珠子拖拽使用 `catchtouchstart`（已存在），会阻止事件冒泡
- 画布旋转使用 `bindtouchstart`，只在未命中珠子时触发
- 添加判断：如果触摸起始点在珠子上，不启动旋转模式

**修改 `onTouchStartRotate`：**
```javascript
onTouchStartRotate(e) {
  // 检查是否触摸在珠子上（通过坐标判断）
  if (this._isTouchOnBead(e.touches[0])) {
    return // 让珠子拖拽处理
  }
  
  if (e.touches.length === 1) {
    // 单指旋转逻辑
    // ...
  }
  // ...
}
```

**新增辅助方法 `_isTouchOnBead`：**
```javascript
_isTouchOnBead(touch) {
  const rect = this._ringRect
  if (!rect) return false
  
  const scale = this.data.canvasScale
  const relX = (touch.clientX - rect.left) / scale
  const relY = (touch.clientY - rect.top) / scale
  
  // 检查是否在任何珠子的区域内
  const { beadPositions } = this.data
  for (let i = 0; i < beadPositions.length; i++) {
    const pos = beadPositions[i]
    if (pos.size <= 0) continue
    
    const halfSize = pos.size / 2
    const centerX = pos.x + halfSize
    const centerY = pos.y + halfSize
    const dist = Math.sqrt(Math.pow(relX - centerX, 2) + Math.pow(relY - centerY, 2))
    
    if (dist < halfSize) return true
  }
  return false
}
```

### 第3步：优化旋转体验

**添加惯性旋转（可选）：**
- 记录滑动速度，松手后继续惯性旋转
- 但为简化，先实现基础功能，惯性可作为后续优化

**旋转灵敏度调整：**
- 当前是直接使用角度差，可能需要调整系数
- 测试后如需要，可添加灵敏度系数

## 不变的部分

- 双指缩放功能完全保留
- 珠子拖拽功能完全保留（使用 catchtouch 阻止冒泡）
- 旋转按钮功能保留
- 自动旋转功能保留
- Canvas 缩略图生成逻辑

## 验证步骤

1. 单指在画布空白处滑动 → 手串跟随手指旋转
2. 单指在珠子上拖拽 → 拖拽珠子，不旋转画布
3. 双指捏合 → 画布缩放（原有功能）
4. 点击旋转按钮 → 步进旋转（原有功能）
5. 保存设计 → 缩略图正确显示旋转后的状态
