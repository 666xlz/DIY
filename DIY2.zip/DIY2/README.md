# 水晶手串DIY定制下单微信小程序

## 项目简介

一款基于微信原生语法 + 微信云开发的定制手串DIY小程序，用户可以选择各种水晶圆珠、隔片、吊坠和配饰，可视化设计手串并一键下单。

## 技术栈

- 微信小程序原生 WXML / WXSS / JS
- 微信云开发（云数据库、云存储、云函数）
- 无第三方框架依赖

## 项目结构

```
├── miniprogram/                  # 小程序源码
│   ├── app.js                    # 全局入口（云开发初始化）
│   ├── app.json                  # 全局配置（页面路由、TabBar）
│   ├── app.wxss                  # 全局样式（CSS变量、通用组件）
│   ├── utils/
│   │   └── util.js               # 工具函数
│   ├── components/
│   │   └── custom-tab-bar/       # 自定义底部TabBar
│   └── pages/
│       ├── index/                # 首页（分类、推荐、入口）
│       ├── design/               # DIY设计核心页（环形预览、素材选择）
│       ├── order/                # 下单确认页
│       ├── mine/                 # 个人中心
│       ├── my-designs/           # 我的设计列表
│       ├── my-orders/            # 我的订单列表
│       ├── address/              # 地址管理
│       ├── address-edit/         # 地址编辑
│       └── admin/                # 素材管理后台
│           └── material-edit/    # 素材编辑
├── cloudfunctions/               # 云函数
│   ├── login/                    # 获取用户OpenID
│   ├── initData/                 # 初始化示例数据
│   ├── manageMaterials/          # 素材增删改查
│   ├── manageDesigns/            # 设计方案管理
│   ├── manageOrders/             # 订单管理
│   └── manageAddresses/          # 地址管理
└── project.config.json           # 项目配置
```

## 云数据库集合

| 集合名 | 说明 | 主要字段 |
|--------|------|----------|
| categories | 素材分类 | name, type, sort, status |
| materials | 素材（珠子/配饰） | name, category, type, price(分), stock, specs, image, sort, status |
| designs | 用户设计方案 | name, beads[], totalPrice(分), wristSize, beadCount, status |
| orders | 订单 | orderNo, beads[], totalPrice(分), wristSize, address{}, status, remark |
| addresses | 收货地址 | name, phone, province, city, district, detail, isDefault |

## 云函数说明

| 函数名 | 说明 |
|--------|------|
| login | 获取用户 OpenID |
| initData | 初始化分类和素材示例数据 |
| manageMaterials | 素材CRUD、分类CRUD |
| manageDesigns | 设计方案保存/更新/列表/删除 |
| manageOrders | 订单创建/列表/取消/确认收货 |
| manageAddresses | 地址增删改查/默认地址管理 |

## 部署步骤

1. 在微信开发者工具中打开项目
2. 右键 `cloudfunctions` 目录，选择「同步云函数列表」
3. 逐个右键每个云函数目录，选择「上传并部署：云端安装依赖」
4. 在云开发控制台创建以下集合：categories, materials, designs, orders, addresses
5. 部署完成后，进入「素材管理」页面，点击「一键初始化示例数据」填充测试数据

## 云开发环境

- 环境 ID: `cloud1-d8gd35ywhed1bca7d`
- 区域: 上海
- 版本: 个人版

## 颜色体系

| 角色 | 色值 | 用途 |
|------|------|------|
| Primary | #1A5C5E | 主色、导航、按钮 |
| Gold | #C4973B | 强调、价格、装饰 |
| Background | #FDF8F0 | 页面背景 |
| Rose | #D4A68C | 辅助强调 |
| Text | #2D2D2D | 正文 |
| Danger | #C44B4B | 价格、删除 |
