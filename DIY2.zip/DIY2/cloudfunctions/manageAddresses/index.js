// 云函数 - manageAddresses：地址管理
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async (event, context) => {
  const { action, data, _id } = event
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  // 新增地址
  if (action === 'add') {
    // 如果设为默认，先取消其他默认
    if (data.isDefault) {
      const existings = await db.collection('addresses')
        .where({ _openid: openid, isDefault: true })
        .get()
      for (const item of existings.data) {
        await db.collection('addresses').doc(item._id).update({ data: { isDefault: false } })
      }
    }
    const res = await db.collection('addresses').add({
      data: { ...data, _openid: openid, createTime: db.serverDate() }
    })
    return { success: true, _id: res._id }
  }

  // 更新地址
  if (action === 'update') {
    if (data.isDefault) {
      const existings = await db.collection('addresses')
        .where({ _openid: openid, isDefault: true })
        .get()
      for (const item of existings.data) {
        await db.collection('addresses').doc(item._id).update({ data: { isDefault: false } })
      }
    }
    const { _id: id, ...updateData } = data
    await db.collection('addresses').doc(_id).update({ data: updateData })
    return { success: true }
  }

  // 地址列表
  if (action === 'list') {
    const res = await db.collection('addresses')
      .where({ _openid: openid })
      .orderBy('isDefault', 'desc')
      .orderBy('createTime', 'desc')
      .get()
    return res.data
  }

  // 删除地址
  if (action === 'delete') {
    await db.collection('addresses').doc(_id).remove()
    return { success: true }
  }

  // 获取默认地址
  if (action === 'getDefault') {
    const res = await db.collection('addresses')
      .where({ _openid: openid, isDefault: true })
      .limit(1)
      .get()
    return res.data.length > 0 ? res.data[0] : null
  }

  return { success: false, message: 'unknown action' }
}
