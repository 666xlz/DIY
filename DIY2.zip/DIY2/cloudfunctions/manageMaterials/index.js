// 云函数 - manageMaterials：素材增删改查
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { action, data, _id } = event
  const wxContext = cloud.getWXContext()

  // 获取素材列表（支持分类筛选）
  if (action === 'list') {
    const { type, category, page = 1, pageSize = 20 } = data || {}
    let query = db.collection('materials').where({ status: 1 })
    if (type) query = query.where({ type, status: 1 })
    if (category) query = query.where({ category, status: 1 })

    const total = (await query.count()).total
    const res = await query
      .orderBy('sort', 'asc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get()

    return { list: res.data, total, page, pageSize }
  }

  // 获取素材详情
  if (action === 'detail') {
    const res = await db.collection('materials').doc(_id).get()
    return res.data
  }

  // 新增素材
  if (action === 'add') {
    const res = await db.collection('materials').add({
      data: { ...data, createTime: db.serverDate(), sales: 0, status: 1 }
    })
    return { success: true, _id: res._id }
  }

  // 更新素材
  if (action === 'update') {
    const { _id: id, ...updateData } = data
    await db.collection('materials').doc(_id).update({ data: updateData })
    return { success: true }
  }

  // 删除素材（软删除）
  if (action === 'delete') {
    await db.collection('materials').doc(_id).update({ data: { status: 0 } })
    return { success: true }
  }

  // 获取分类列表
  if (action === 'categories') {
    const { type } = data || {}
    let query = db.collection('categories').where({ status: 1 })
    if (type) query = query.where({ type, status: 1 })
    const res = await query.orderBy('sort', 'asc').get()
    return res.data
  }

  // 新增分类
  if (action === 'addCategory') {
    const res = await db.collection('categories').add({ data })
    return { success: true, _id: res._id }
  }

  return { success: false, message: 'unknown action' }
}
