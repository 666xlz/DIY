// 云函数 - manageOrders：订单管理
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { action, data, _id } = event
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  // 创建订单
  if (action === 'create') {
    const orderNo = 'ORD' + Date.now() + Math.floor(Math.random() * 1000)
    const res = await db.collection('orders').add({
      data: {
        ...data,
        _openid: openid,
        orderNo,
        status: 'pending',
        createTime: db.serverDate()
      }
    })
    return { success: true, _id: res._id, orderNo }
  }

  // 我的订单列表
  if (action === 'myList') {
    const { page = 1, pageSize = 10, status } = data || {}
    let where = { _openid: openid }
    if (status) where.status = status
    const query = db.collection('orders').where(where)
    const total = (await query.count()).total
    const res = await query
      .orderBy('createTime', 'desc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get()
    return { list: res.data, total }
  }

  // 订单详情
  if (action === 'detail') {
    const res = await db.collection('orders').doc(_id).get()
    return res.data
  }

  // 取消订单
  if (action === 'cancel') {
    const doc = await db.collection('orders').doc(_id).get()
    if (doc.data._openid !== openid) {
      return { success: false, message: '无权操作' }
    }
    await db.collection('orders').doc(_id).update({
      data: { status: 'cancelled' }
    })
    return { success: true }
  }

  // 确认收货
  if (action === 'confirm') {
    const doc = await db.collection('orders').doc(_id).get()
    if (doc.data._openid !== openid) {
      return { success: false, message: '无权操作' }
    }
    await db.collection('orders').doc(_id).update({
      data: { status: 'completed' }
    })
    return { success: true }
  }

  return { success: false, message: 'unknown action' }
}
