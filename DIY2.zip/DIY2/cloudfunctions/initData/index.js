// 云函数 - initData：初始化数据库集合和示例数据
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async (event, context) => {
  const { action } = event

  if (action === 'initCategories') {
    const categories = [
      { name: '天然水晶', type: 'bead', icon: '', sort: 1, status: 1 },
      { name: '玛瑙玉髓', type: 'bead', icon: '', sort: 2, status: 1 },
      { name: '月光石', type: 'bead', icon: '', sort: 3, status: 1 },
      { name: '碧玺', type: 'bead', icon: '', sort: 4, status: 1 },
      { name: '石榴石', type: 'bead', icon: '', sort: 5, status: 1 },
      { name: '虎眼石', type: 'bead', icon: '', sort: 6, status: 1 },
      { name: '金属隔片', type: 'spacer', icon: '', sort: 1, status: 1 },
      { name: '天然石隔片', type: 'spacer', icon: '', sort: 2, status: 1 },
      { name: '藏银隔片', type: 'spacer', icon: '', sort: 3, status: 1 },
      { name: '小吊坠', type: 'pendant', icon: '', sort: 1, status: 1 },
      { name: '佛像吊坠', type: 'pendant', icon: '', sort: 2, status: 1 },
      { name: '生肖吊坠', type: 'pendant', icon: '', sort: 3, status: 1 },
      { name: '流苏', type: 'ornament', icon: '', sort: 1, status: 1 },
      { name: '平安扣', type: 'ornament', icon: '', sort: 2, status: 1 }
    ]

    const tasks = categories.map(cat => {
      return db.collection('categories').add({ data: cat })
    })
    await Promise.all(tasks)
    return { success: true, count: categories.length }
  }

  if (action === 'initMaterials') {
    const materials = [
      { name: '紫水晶圆珠8mm', category: '天然水晶', type: 'bead', price: 580, stock: 200, specs: { size: '8mm', color: '紫色', material: '紫水晶' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '粉水晶圆珠8mm', category: '天然水晶', type: 'bead', price: 380, stock: 300, specs: { size: '8mm', color: '粉色', material: '粉水晶' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '白水晶圆珠8mm', category: '天然水晶', type: 'bead', price: 280, stock: 500, specs: { size: '8mm', color: '白色', material: '白水晶' }, image: '', sort: 3, status: 1, sales: 0 },
      { name: '黄水晶圆珠8mm', category: '天然水晶', type: 'bead', price: 480, stock: 150, specs: { size: '8mm', color: '黄色', material: '黄水晶' }, image: '', sort: 4, status: 1, sales: 0 },
      { name: '茶晶圆珠8mm', category: '天然水晶', type: 'bead', price: 320, stock: 200, specs: { size: '8mm', color: '茶色', material: '茶晶' }, image: '', sort: 5, status: 1, sales: 0 },
      { name: '发晶圆珠8mm', category: '天然水晶', type: 'bead', price: 880, stock: 100, specs: { size: '8mm', color: '金色', material: '金发晶' }, image: '', sort: 6, status: 1, sales: 0 },
      { name: '红玛瑙圆珠8mm', category: '玛瑙玉髓', type: 'bead', price: 350, stock: 250, specs: { size: '8mm', color: '红色', material: '红玛瑙' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '蓝玛瑙圆珠8mm', category: '玛瑙玉髓', type: 'bead', price: 420, stock: 180, specs: { size: '8mm', color: '蓝色', material: '蓝玛瑙' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '绿玛瑙圆珠8mm', category: '玛瑙玉髓', type: 'bead', price: 380, stock: 200, specs: { size: '8mm', color: '绿色', material: '绿玛瑙' }, image: '', sort: 3, status: 1, sales: 0 },
      { name: '月光石圆珠8mm', category: '月光石', type: 'bead', price: 680, stock: 120, specs: { size: '8mm', color: '蓝白', material: '月光石' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '彩虹月光石8mm', category: '月光石', type: 'bead', price: 980, stock: 60, specs: { size: '8mm', color: '彩虹', material: '彩虹月光石' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '红碧玺圆珠8mm', category: '碧玺', type: 'bead', price: 1280, stock: 50, specs: { size: '8mm', color: '红色', material: '红碧玺' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '绿碧玺圆珠8mm', category: '碧玺', type: 'bead', price: 1180, stock: 60, specs: { size: '8mm', color: '绿色', material: '绿碧玺' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '红石榴石圆珠8mm', category: '石榴石', type: 'bead', price: 520, stock: 200, specs: { size: '8mm', color: '酒红', material: '石榴石' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '金虎眼石圆珠8mm', category: '虎眼石', type: 'bead', price: 450, stock: 200, specs: { size: '8mm', color: '金色', material: '金虎眼石' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '蓝虎眼石圆珠8mm', category: '虎眼石', type: 'bead', price: 520, stock: 150, specs: { size: '8mm', color: '蓝色', material: '蓝虎眼石' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '藏银莲花隔片', category: '金属隔片', type: 'spacer', price: 280, stock: 300, specs: { size: '6mm', color: '银色', material: '藏银' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '黄铜圆隔片', category: '金属隔片', type: 'spacer', price: 180, stock: 500, specs: { size: '6mm', color: '金色', material: '黄铜' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '绿松石隔片', category: '天然石隔片', type: 'spacer', price: 380, stock: 200, specs: { size: '6mm', color: '绿色', material: '绿松石' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '小如意吊坠', category: '小吊坠', type: 'pendant', price: 680, stock: 100, specs: { size: '12mm', color: '银色', material: '925银' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '小葫芦吊坠', category: '小吊坠', type: 'pendant', price: 580, stock: 120, specs: { size: '10mm', color: '金色', material: '黄铜鎏金' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '弥勒佛吊坠', category: '佛像吊坠', type: 'pendant', price: 1280, stock: 50, specs: { size: '15mm', color: '金色', material: '黄铜鎏金' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '金色流苏', category: '流苏', type: 'ornament', price: 350, stock: 200, specs: { size: '40mm', color: '金色', material: '丝线' }, image: '', sort: 1, status: 1, sales: 0 },
      { name: '红色流苏', category: '流苏', type: 'ornament', price: 350, stock: 200, specs: { size: '40mm', color: '红色', material: '丝线' }, image: '', sort: 2, status: 1, sales: 0 },
      { name: '平安扣配件', category: '平安扣', type: 'ornament', price: 480, stock: 150, specs: { size: '12mm', color: '绿色', material: '和田玉' }, image: '', sort: 1, status: 1, sales: 0 }
    ]

    const tasks = materials.map(m => {
      return db.collection('materials').add({ data: { ...m, createTime: db.serverDate() } })
    })
    await Promise.all(tasks)
    return { success: true, count: materials.length }
  }

  return { success: false, message: 'unknown action' }
}
