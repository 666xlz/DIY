// 云函数 - manageDesigns：设计方案增删改查
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { action, data, _id } = event
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  // 保存设计方案
  if (action === 'save') {
    const res = await db.collection('designs').add({
      data: {
        ...data,
        _openid: openid,
        createTime: db.serverDate(),
        updateTime: db.serverDate(),
        status: 1
      }
    })
    return { success: true, _id: res._id }
  }

  // 更新设计方案
  if (action === 'update') {
    // 校验归属
    const doc = await db.collection('designs').doc(_id).get()
    if (doc.data._openid !== openid) {
      return { success: false, message: '无权操作' }
    }
    const { _id: id, ...updateData } = data
    await db.collection('designs').doc(_id).update({
      data: { ...updateData, updateTime: db.serverDate() }
    })
    return { success: true }
  }

  // 获取我的设计列表
  if (action === 'myList') {
    const { page = 1, pageSize = 10 } = data || {}
    const query = db.collection('designs').where({ _openid: openid, status: 1 })
    const total = (await query.count()).total
    const res = await query
      .orderBy('updateTime', 'desc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get()
    return { list: res.data, total }
  }

  // 删除设计方案
  if (action === 'delete') {
    const doc = await db.collection('designs').doc(_id).get()
    if (doc.data._openid !== openid) {
      return { success: false, message: '无权操作' }
    }
    await db.collection('designs').doc(_id).update({ data: { status: 0 } })
    return { success: true }
  }

  // 获取设计详情
  if (action === 'detail') {
    const res = await db.collection('designs').doc(_id).get()
    return res.data
  }

  return { success: false, message: 'unknown action' }
}
