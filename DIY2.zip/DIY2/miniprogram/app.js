// app.js
App({
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'cloud1-d8gd35ywhed1bca7d',
        traceUser: true
      })
    }
    this.globalData = {
      userInfo: null,
      openid: null,
      envId: 'cloud1-d8gd35ywhed1bca7d'
    }
    // 获取 openid
    this.getOpenId()
  },

  getOpenId() {
    if (this.globalData.openid) return Promise.resolve(this.globalData.openid)
    return wx.cloud.callFunction({
      name: 'login'
    }).then(res => {
      this.globalData.openid = res.result.openid
      return res.result.openid
    })
  }
})
