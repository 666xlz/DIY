Component({
  data: {
    selected: 0,
    list: [
      { pagePath: '/pages/index/index', text: '首页' },
      { pagePath: '/pages/design/design', text: 'DIY设计' },
      { pagePath: '/pages/mine/mine', text: '个人中心' }
    ]
  },

  lifetimes: {
    attached() {
      this.setSelected()
    }
  },

  pageLifetimes: {
    show() {
      this.setSelected()
    }
  },

  methods: {
    setSelected() {
      const pages = getCurrentPages()
      const currentPage = pages[pages.length - 1]
      const url = '/' + currentPage.route
      const list = this.data.list
      for (let i = 0; i < list.length; i++) {
        if (list[i].pagePath === url) {
          this.setData({ selected: i })
          return
        }
      }
    },

    switchTab(e) {
      const idx = e.currentTarget.dataset.index
      const url = this.data.list[idx].pagePath
      wx.switchTab({ url })
    }
  }
})
