const envList = [{"envId":"cloud1-d8gd35ywhed1bca7d","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}