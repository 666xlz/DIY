// utils/util.js
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()
  return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

/**
 * 格式化价格为两位小数
 */
const formatPrice = price => {
  return (price / 100).toFixed(2)
}

/**
 * 价格显示（分转元）
 */
const priceYuan = price => {
  return '¥' + (price / 100).toFixed(2)
}

/**
 * 生成唯一ID
 */
const genId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 6)
}

/**
 * 手围尺寸选项（cm）
 */
const WRIST_SIZES = [14, 14.5, 15, 15.5, 16, 16.5, 17, 17.5, 18, 18.5, 19, 19.5, 20]

/**
 * 素材类型映射
 */
const MATERIAL_TYPES = {
  bead: '圆珠',
  spacer: '隔片',
  ornament: '配饰',
  pendant: '吊坠'
}

/**
 * 订单状态映射
 */
const ORDER_STATUS = {
  pending: '待付款',
  paid: '已付款',
  producing: '制作中',
  shipped: '已发货',
  completed: '已完成',
  cancelled: '已取消'
}

module.exports = {
  formatTime,
  formatPrice,
  priceYuan,
  genId,
  WRIST_SIZES,
  MATERIAL_TYPES,
  ORDER_STATUS
}
