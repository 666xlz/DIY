// 个人中心
const app = getApp()

Page({
  data: {
    userInfo: null,
    hasUserInfo: false
  },

  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setSelected()
    }
    this.getUserProfile()
  },

  async getUserProfile() {
    try {
      const res = await wx.cloud.callFunction({ name: 'login' })
      if (res.result.openid) {
        this.setData({ hasUserInfo: true })
      }
    } catch (e) {
      console.error(e)
    }
  },

  // 我的订单
  onGoMyOrders() {
    wx.navigateTo({ url: '/pages/my-orders/my-orders' })
  },

  // 我的设计
  onGoMyDesigns() {
    wx.navigateTo({ url: '/pages/my-designs/my-designs' })
  },

  // 地址管理
  onGoAddress() {
    wx.navigateTo({ url: '/pages/address/address' })
  },

  // 管理后台
  onGoAdmin() {
    wx.navigateTo({ url: '/pages/admin/admin' })
  }
})
