// 下单页
const app = getApp()
const { ORDER_STATUS } = require('../../utils/util')

Page({
  data: {
    design: null,
    beads: [],
    totalPrice: 0,
    wristSize: 16,
    beadCount: 0,
    previewImage: '',

    // 地址
    address: null,

    // 备注
    remark: '',

    // 提交中
    submitting: false
  },

  onLoad() {
    const design = app.globalData.currentDesign
    if (!design) {
      wx.showToast({ title: '请先设计手串', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 1500)
      return
    }
    const beads = design.beads.filter(b => b.materialId)
    this.setData({
      design,
      beads,
      totalPrice: design.totalPrice,
      wristSize: design.wristSize || 16,
      beadCount: design.beadCount,
      previewImage: design.previewImage || ''
    })
    this._resolveCloudImages(beads)
    this.loadDefaultAddress()
  },

  // 批量将 cloud:// 图片 URL 转换为临时 HTTP URL（仅用于前端显示）
  // 原始 cloud:// URL 保存到 cloudImage 字段，提交订单时需还原
  async _resolveCloudImages(list, imageField = 'image') {
    const cloudItems = []
    list.forEach((item, idx) => {
      if (item[imageField] && String(item[imageField]).startsWith('cloud://')) {
        cloudItems.push({ idx, fileID: item[imageField] })
      }
    })
    if (!cloudItems.length) return

    try {
      for (let i = 0; i < cloudItems.length; i += 50) {
        const batch = cloudItems.slice(i, i + 50)
        const res = await wx.cloud.getTempFileURL({
          fileList: batch.map(b => b.fileID)
        })
        if (res.fileList) {
          res.fileList.forEach(f => {
            if (f.status === 0 && f.tempFileURL) {
              const match = batch.find(b => b.fileID === f.fileID)
              if (match) {
                // 保留原始 cloud:// URL 到 cloudImage
                list[match.idx].cloudImage = list[match.idx][imageField]
                list[match.idx][imageField] = f.tempFileURL
              }
            }
          })
          // 触发视图更新
          this.setData({ beads: list })
        }
      }
    } catch (e) {
      console.error('cloud://图片URL转换失败', e)
    }
  },

  // 加载默认地址
  async loadDefaultAddress() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageAddresses',
        data: { action: 'getDefault' }
      })
      if (res.result) {
        this.setData({ address: res.result })
      }
    } catch (e) {
      console.error('加载地址失败', e)
    }
  },

  // 选择地址
  onSelectAddress() {
    wx.navigateTo({
      url: '/pages/address/address?select=1'
    })
  },

  // 输入备注
  onInputRemark(e) {
    this.setData({ remark: e.detail.value })
  },

  // 提交订单
  async onSubmitOrder() {
    if (!this.data.address) {
      wx.showToast({ title: '请选择收货地址', icon: 'none' })
      return
    }

    const validBeads = this.data.beads
    if (!validBeads.length) {
      wx.showToast({ title: '手串无有效珠子', icon: 'none' })
      return
    }

    this.setData({ submitting: true })
    wx.showLoading({ title: '提交中...' })

    try {
      // 提交时还原 image 为原始 cloud:// URL
      const submitBeads = validBeads.map(b => {
        const bead = { ...b }
        if (bead.cloudImage) {
          bead.image = bead.cloudImage
          delete bead.cloudImage
        }
        return bead
      })

      const res = await wx.cloud.callFunction({
        name: 'manageOrders',
        data: {
          action: 'create',
          data: {
            beads: submitBeads,
            totalPrice: this.data.totalPrice,
            wristSize: this.data.wristSize,
            beadCount: this.data.beadCount,
            address: {
              name: this.data.address.name,
              phone: this.data.address.phone,
              province: this.data.address.province,
              city: this.data.address.city,
              district: this.data.address.district,
              detail: this.data.address.detail
            },
            remark: this.data.remark
          }
        }
      })

      wx.hideLoading()
      this.setData({ submitting: false })

      if (res.result.success) {
        wx.showToast({ title: '下单成功', icon: 'success' })
        setTimeout(() => {
          wx.redirectTo({ url: '/pages/my-orders/my-orders' })
        }, 1500)
      }
    } catch (e) {
      wx.hideLoading()
      this.setData({ submitting: false })
      wx.showToast({ title: '下单失败', icon: 'none' })
      console.error(e)
    }
  }
})
