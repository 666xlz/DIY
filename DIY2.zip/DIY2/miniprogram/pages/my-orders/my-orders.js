// 我的订单
const { ORDER_STATUS } = require('../../utils/util')

Page({
  data: {
    orders: [],
    loading: true,
    page: 1,
    hasMore: true,
    ORDER_STATUS
  },

  onShow() {
    this.setData({ page: 1, orders: [], hasMore: true })
    this.loadOrders()
  },

  async loadOrders() {
    if (!this.data.hasMore) return
    this.setData({ loading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageOrders',
        data: {
          action: 'myList',
          data: { page: this.data.page, pageSize: 10 }
        }
      })
      const list = res.result.list || []
      this.setData({
        orders: this.data.orders.concat(list),
        hasMore: list.length >= 10,
        page: this.data.page + 1,
        loading: false
      })
    } catch (e) {
      console.error('加载订单失败', e)
      this.setData({ loading: false })
    }
  },

  onReachBottom() {
    this.loadOrders()
  },

  // 取消订单
  onCancelOrder(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认取消',
      content: '确定取消此订单？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await wx.cloud.callFunction({
              name: 'manageOrders',
              data: { action: 'cancel', _id: id }
            })
            wx.showToast({ title: '已取消', icon: 'success' })
            this.setData({ page: 1, orders: [], hasMore: true })
            this.loadOrders()
          } catch (e) {
            wx.showToast({ title: '操作失败', icon: 'none' })
          }
        }
      }
    })
  },

  // 确认收货
  onConfirmOrder(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认收货',
      content: '确认已收到商品？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await wx.cloud.callFunction({
              name: 'manageOrders',
              data: { action: 'confirm', _id: id }
            })
            wx.showToast({ title: '已确认收货', icon: 'success' })
            this.setData({ page: 1, orders: [], hasMore: true })
            this.loadOrders()
          } catch (e) {
            wx.showToast({ title: '操作失败', icon: 'none' })
          }
        }
      }
    })
  },

  getStatusText(status) {
    return ORDER_STATUS[status] || status
  }
})
