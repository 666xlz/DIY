// 我的设计列表
Page({
  data: {
    designs: [],
    loading: true,
    page: 1,
    hasMore: true
  },

  onShow() {
    this.setData({ page: 1, designs: [], hasMore: true })
    this.loadDesigns()
  },

  async loadDesigns() {
    if (!this.data.hasMore) return
    this.setData({ loading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageDesigns',
        data: {
          action: 'myList',
          data: { page: this.data.page, pageSize: 10 }
        }
      })
      const list = res.result.list || []
      this.setData({
        designs: this.data.designs.concat(list),
        hasMore: list.length >= 10,
        page: this.data.page + 1,
        loading: false
      })
    } catch (e) {
      console.error('加载设计失败', e)
      this.setData({ loading: false })
    }
  },

  onReachBottom() {
    this.loadDesigns()
  },

  // 编辑设计
  onEditDesign(e) {
    const id = e.currentTarget.dataset.id
    wx.switchTab({
      url: '/pages/design/design',
      success: () => {
        // 通过 globalData 传递编辑ID
        const page = getCurrentPages().find(p => p.route === 'pages/design/design')
        if (page) {
          page.loadDesign(id)
        }
      }
    })
  },

  // 用此设计下单
  onOrderDesign(e) {
    const index = e.currentTarget.dataset.index
    const design = this.data.designs[index]
    const app = getApp()
    app.globalData.currentDesign = {
      beads: design.beads,
      totalPrice: design.totalPrice,
      wristSize: design.wristSize,
      beadCount: design.beadCount,
      previewImage: design.previewImage || ''
    }
    wx.navigateTo({ url: '/pages/order/order' })
  },

  // 删除设计
  onDeleteDesign(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认删除',
      content: '确定删除此设计方案？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await wx.cloud.callFunction({
              name: 'manageDesigns',
              data: { action: 'delete', _id: id }
            })
            wx.showToast({ title: '已删除', icon: 'success' })
            this.setData({ page: 1, designs: [], hasMore: true })
            this.loadDesigns()
          } catch (e) {
            wx.showToast({ title: '删除失败', icon: 'none' })
          }
        }
      }
    })
  },

  // 新建设计
  onCreateDesign() {
    wx.switchTab({ url: '/pages/design/design' })
  }
})
