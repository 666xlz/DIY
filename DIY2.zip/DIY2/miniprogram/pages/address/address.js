// 地址列表页
Page({
  data: {
    addresses: [],
    selectMode: false,
    loading: true
  },

  onLoad(options) {
    if (options.select === '1') {
      this.setData({ selectMode: true })
    }
  },

  onShow() {
    this.loadAddresses()
  },

  async loadAddresses() {
    this.setData({ loading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageAddresses',
        data: { action: 'list' }
      })
      this.setData({ addresses: res.result || [], loading: false })
    } catch (e) {
      console.error('加载地址失败', e)
      this.setData({ loading: false })
    }
  },

  // 选择地址（下单页进来时）
  onSelectAddress(e) {
    if (!this.data.selectMode) return
    const index = e.currentTarget.dataset.index
    const address = this.data.addresses[index]
    const pages = getCurrentPages()
    const prevPage = pages[pages.length - 2]
    if (prevPage && prevPage.setData) {
      prevPage.setData({ address })
    }
    wx.navigateBack()
  },

  // 编辑地址
  onEditAddress(e) {
    const index = e.currentTarget.dataset.index
    const addr = this.data.addresses[index]
    wx.navigateTo({
      url: '/pages/address-edit/address-edit?id=' + addr._id
    })
  },

  // 新增地址
  onAddAddress() {
    wx.navigateTo({ url: '/pages/address-edit/address-edit' })
  },

  // 删除地址
  onDeleteAddress(e) {
    const index = e.currentTarget.dataset.index
    const addr = this.data.addresses[index]
    wx.showModal({
      title: '确认删除',
      content: '确定删除该地址？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await wx.cloud.callFunction({
              name: 'manageAddresses',
              data: { action: 'delete', _id: addr._id }
            })
            wx.showToast({ title: '已删除', icon: 'success' })
            this.loadAddresses()
          } catch (e) {
            wx.showToast({ title: '删除失败', icon: 'none' })
          }
        }
      }
    })
  }
})
