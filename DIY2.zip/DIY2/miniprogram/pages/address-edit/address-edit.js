// 地址编辑页
Page({
  data: {
    _id: '',
    name: '',
    phone: '',
    province: '',
    city: '',
    district: '',
    detail: '',
    isDefault: false,
    isEdit: false
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ _id: options.id, isEdit: true })
      this.loadAddress(options.id)
    }
  },

  async loadAddress(id) {
    try {
      const db = wx.cloud.database()
      const res = await db.collection('addresses').doc(id).get()
      const addr = res.data
      this.setData({
        name: addr.name,
        phone: addr.phone,
        province: addr.province,
        city: addr.city,
        district: addr.district,
        detail: addr.detail,
        isDefault: addr.isDefault
      })
    } catch (e) {
      console.error('加载地址失败', e)
    }
  },

  onInputName(e) { this.setData({ name: e.detail.value }) },
  onInputPhone(e) { this.setData({ phone: e.detail.value }) },
  onInputDetail(e) { this.setData({ detail: e.detail.value }) },

  onSwitchDefault(e) {
    this.setData({ isDefault: e.detail.value })
  },

  // 选择地区
  onChooseRegion(e) {
    const region = e.detail.value
    this.setData({
      province: region[0],
      city: region[1],
      district: region[2]
    })
  },

  // 保存
  async onSave() {
    const { name, phone, province, city, district, detail, isDefault, _id } = this.data
    if (!name.trim()) { wx.showToast({ title: '请输入姓名', icon: 'none' }); return }
    if (!phone.trim() || phone.length < 11) { wx.showToast({ title: '请输入正确手机号', icon: 'none' }); return }
    if (!province) { wx.showToast({ title: '请选择地区', icon: 'none' }); return }
    if (!detail.trim()) { wx.showToast({ title: '请输入详细地址', icon: 'none' }); return }

    wx.showLoading({ title: '保存中...' })
    try {
      const addrData = { name, phone, province, city, district, detail, isDefault }
      if (_id) {
        await wx.cloud.callFunction({
          name: 'manageAddresses',
          data: { action: 'update', _id, data: addrData }
        })
      } else {
        await wx.cloud.callFunction({
          name: 'manageAddresses',
          data: { action: 'add', data: addrData }
        })
      }
      wx.hideLoading()
      wx.showToast({ title: '保存成功', icon: 'success' })
      setTimeout(() => wx.navigateBack(), 1000)
    } catch (e) {
      wx.hideLoading()
      wx.showToast({ title: '保存失败', icon: 'none' })
      console.error(e)
    }
  }
})
