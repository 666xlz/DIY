// 首页
const app = getApp()
const { priceYuan, MATERIAL_TYPES } = require('../../utils/util')

Page({
  data: {
    categories: [],
    hotDesigns: [],
    cases: [],
    loading: true
  },

  onLoad() {
    this.loadHotDesigns()
    this.loadCases()
  },

  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setSelected()
    }
  },

  onPullDownRefresh() {
    this.loadHotDesigns()
    this.loadCases()
    wx.stopPullDownRefresh()
  },

  // 加载热门设计
  async loadHotDesigns() {
    try {
      const db = wx.cloud.database()
      const res = await db.collection('designs')
        .where({ status: 1, isHot: true })
        .orderBy('createTime', 'desc')
        .limit(6)
        .get()
      this.setData({ hotDesigns: res.data })
    } catch (e) {
      console.error('加载热门设计失败', e)
    }
  },

  // 点击热门设计
  onTapDesign(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: '/pages/design/design?designId=' + id
    })
  },

  // 进入DIY
  onStartDIY() {
    wx.switchTab({
      url: '/pages/design/design'
    })
  },

  // 加载精品案例
  async loadCases() {
    try {
      const db = wx.cloud.database()
      const res = await db.collection('designs')
        .where({ status: 1 })
        .orderBy('createTime', 'desc')
        .limit(10)
        .get()
      if (res.data && res.data.length) {
        this.setData({ cases: res.data })
      }
    } catch (e) {
      console.error('加载案例失败', e)
    }
  },

  // 点击案例 - 进入DIY设计页复刻

 onTapCase(e) {
  const { id } = e.currentTarget.dataset;
  getApp().globalData.copyDesignId = id;

  // 重点：url 里 什么参数都不能带！
  wx.switchTab({
    url: '/pages/design/design'
  });
 },

  // 进入管理后台
  onGoAdmin() {
    wx.navigateTo({
      url: '/pages/admin/admin'
    })
  }
})
