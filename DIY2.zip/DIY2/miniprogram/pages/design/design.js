// DIY设计核心页
const app = getApp()
const { priceYuan, MATERIAL_TYPES } = require('../../utils/util')

const DEFAULT_BEAD_COUNT = 20
const PX_PER_MM = 4  // 8mm=32px

Page({
  data: {
    categories: [],
    filteredCategories: [],
    activeType: 'bead',
    activeCategory: '',
    materialList: [],
    allMaterials: [], // 按type加载的完整素材列表，用于客户端分类过滤
    loading: false,

    bracelet: [],
    beadCount: DEFAULT_BEAD_COUNT,
    totalPrice: 0,
    beadPositions: [],

    centerX: 160,
    centerY: 160,
    ringRadius: 120,

    showSaveModal: false,
    designName: '',
    editingIndex: -1,
    designId: '',

    showSizePicker: false,
    wristSize: 16,
    sizeOptions: [14, 14.5, 15, 15.5, 16, 16.5, 17, 17.5, 18, 18.5, 19, 19.5, 20],

    // 拖拽状态
    isDragging: false,
    dragIndex: -1,
    dragPosition: { x: 0, y: 0 },
    hasAnyBead: false, // 是否有真实珠子，控制阴影圆环显示

    // 旋转相关
    rotation: 0,
    autoRotate: false,

    // 画布视觉缩放
    canvasScale: 1,

    // 垃圾桶拖拽删除
    trashHover: false,

    // 抽屉/搜索/须知
    drawerOpen: false,
    searchKeyword: '',
    filteredMaterialList: [],
    showNotice: false,

    // 尺寸筛选
    selectedSizes: [],       // 已选中的尺寸列表（多选）
    availableSizes: [],      // 当前素材列表中可选的尺寸

    // 状态栏高度（自定义导航栏）
    statusBarHeight: 20,

    // 周长计算
    beadTotalMm: 0,
    beadTotalCm: '0.0',
    isOverLimit: false,
    isUnderTarget: false,

    // 封闭圆形状态
    isClosedCircle: false,
  },
  formatPrice(price) {
    return (price / 100).toFixed(2)
  },
  onLoad(options) {
    const windowInfo = wx.getWindowInfo()
    this.setData({ statusBarHeight: windowInfo.statusBarHeight || 20 })
    // 根据目标手围计算圆环半径
    const targetCircPx = this.data.wristSize * 10 * PX_PER_MM
    let ringRadius = targetCircPx / (2 * Math.PI)
    // 确保圆环不超出屏幕
    const maxRadius = (windowInfo.windowWidth - 80) / 2
    if (ringRadius > maxRadius) ringRadius = maxRadius
    const centerX = ringRadius + 40
    const centerY = ringRadius + 40
    this._maxRadius = maxRadius
    this.setData({ centerX, centerY, ringRadius })

    if (options.designId) {
      this.setData({ designId: options.designId })
      this.loadDesign(options.designId)
    } else {
      this.initEmptyBracelet()
    }
    this.loadCategories()
    // 延迟获取预览环容器位置，用于拖拽坐标转换
    wx.nextTick(() => this._updateRingRect())
  },

  onUnload() {
    // 页面卸载时停止自动旋转
    this.stopAutoRotate()
  },

  onShow() {
    // 每次显示时刷新数据（从后台管理编辑回来后能看到最新素材）
    this._updateRingRect()
    this._updateTrashRect()
    this.loadCategories()

    // 处理从首页「复刻同款」跳转的请求
    const copyDesignId = app.globalData.copyDesignId
    if (copyDesignId) {
      app.globalData.copyDesignId = '' // 清除标记，避免重复触发
      this.loadDesignForCopy(copyDesignId)
    }

    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setSelected()
    }
  },

  // 计算珠子环形位置
  // bead/spacer/ornament 参与圆环排列，pendant 固定底部居中悬挂
  // 每种类型用 trackLen(mm) × PX_PER_MM 作为轨道占用弧长
  computeBeadPositions() {
    const { bracelet, rotation, wristSize } = this.data

    // 圆环周长(px) = 目标手围(mm) × px/mm
    const targetCircPx = wristSize * 10 * PX_PER_MM
    let ringRadius = targetCircPx / (2 * Math.PI)

    // 收集参与圆环排列的珠子（bead/spacer/ornament）和吊坠（pendant）
    const ringBeads = []
    const pendants = []
    let totalTrackMm = 0

    for (let i = 0; i < bracelet.length; i++) {
      const bead = bracelet[i]
      if (!bead.materialId) continue

      if (bead.type === 'pendant') {
        // 吊坠不参与圆环排列
        pendants.push({ idx: i })
      } else {
        // bead/spacer/ornament 参与圆环排列
        const trackLen = bead.trackLen || bead.beadMm || 8
        const trackPx = trackLen * PX_PER_MM
        ringBeads.push({ idx: i, trackPx, trackLen, type: bead.type })
        totalTrackMm += trackLen
      }
    }

    // 参与圆环的珠子总弧长(px)
    let totalSize = 0
    for (const b of ringBeads) totalSize += b.trackPx

    // 封闭圆形判定：珠子总长 > 12cm 时紧缩为封闭圆
    const CLOSE_THRESHOLD_MM = 120
    const isClosedCircle = totalTrackMm > CLOSE_THRESHOLD_MM

    if (isClosedCircle || totalSize > targetCircPx) {
      ringRadius = totalSize / (2 * Math.PI)
    }

    // 确保圆环不超出屏幕
    if (this._maxRadius && ringRadius > this._maxRadius) {
      ringRadius = this._maxRadius
    }

    const centerX = ringRadius + 40
    const centerY = ringRadius + 40

    // 构建位置数组（空位不可见）
    const positions = []
    for (let i = 0; i < bracelet.length; i++) {
      positions.push({ x: 0, y: 0, width: 0, height: 0, size: 0, rotate: 0, isPendant: false })
    }

    if (ringBeads.length === 0 && pendants.length === 0) {
      this.setData({ beadPositions: positions, ringRadius, centerX, centerY, isClosedCircle }, () => {
        wx.nextTick(() => this._updateRingRect())
      })
      return
    }

    // === 圆环排列：bead/spacer/ornament 弧长累加 ===
    let arcPos = 0
    for (const { idx, trackPx, type } of ringBeads) {
      const halfSize = trackPx / 2
      const centerArc = arcPos + halfSize
      const angle = centerArc / ringRadius - Math.PI / 2 + rotation

      // 根据类型计算绘制尺寸和旋转角度
      const bead = bracelet[idx]
      let drawW = trackPx
      let drawH = trackPx
      let rotate = 0
      let zIndex = 3

      if (type === 'bead') {
        // 圆珠：正方形，中心点旋转，展示完整珠子
        drawW = trackPx
        drawH = trackPx
        rotate = (angle + Math.PI / 2) * 180 / Math.PI
        zIndex = 3
      } else if (type === 'spacer') {
        // 隔片：扁平形状，沿圆环切线方向（长边沿切线）
        // 如果有图片尺寸，按真实比例；否则默认扁平比例 3:1
        if (bead.imgW && bead.imgH) {
          const imgRatio = bead.imgW / bead.imgH
          if (imgRatio > 1) {
            // 横向图片：长边沿切线
            drawW = trackPx
            drawH = trackPx / imgRatio
          } else {
            // 纵向图片：短边沿切线，需要转90度
            drawW = trackPx * imgRatio
            drawH = trackPx
          }
        } else {
          // 默认扁平隔片：长边沿切线（水平方向）
          drawW = trackPx
          drawH = trackPx / 3
        }
        // 隔片沿切线方向（切线角度 = 法线角度 + 90度）
        rotate = angle * 180 / Math.PI
        zIndex = 2
      } else if (type === 'ornament') {
        // 配饰：根据宽高比智能判断旋转方式
        let imgRatio = 1
        if (bead.imgW && bead.imgH) {
          imgRatio = bead.imgW / bead.imgH
          // 按真实比例缩放，最大边不超过 trackPx
          const ratio = Math.min(trackPx / bead.imgW, trackPx / bead.imgH)
          drawW = bead.imgW * ratio
          drawH = bead.imgH * ratio
        }

        // 智能旋转判断
        if (imgRatio > 1.5) {
          // 横向很长：平躺，长边沿切线
          rotate = angle * 180 / Math.PI
        } else if (imgRatio < 0.7) {
          // 纵向很长：竖立，短边沿切线（需要转90度让长边竖直）
          rotate = (angle + Math.PI / 2) * 180 / Math.PI
        } else {
          // 接近正方形：按中心点旋转（面向圆心）
          rotate = (angle + Math.PI / 2) * 180 / Math.PI
        }
        zIndex = 4
      }

      positions[idx] = {
        x: centerX + ringRadius * Math.cos(angle) - drawW / 2,
        y: centerY + ringRadius * Math.sin(angle) - drawH / 2,
        width: drawW,
        height: drawH,
        size: trackPx, // 兼容旧逻辑
        rotate,
        zIndex,
        isPendant: false
      }

      arcPos += trackPx
    }

    // === 吊坠定位：固定在圆环最底部居中 ===
    for (const { idx } of pendants) {
      const bead = bracelet[idx]
      let drawW, drawH
      if (bead.imgW && bead.imgH) {
        // 吊坠按真实比例，基准尺寸用 trackLen 或默认 12mm
        const basePx = (bead.trackLen || 12) * PX_PER_MM
        const ratio = Math.min(basePx / bead.imgW, basePx / bead.imgH)
        drawW = bead.imgW * ratio
        drawH = bead.imgH * ratio
      } else {
        const basePx = (bead.trackLen || 12) * PX_PER_MM
        drawW = basePx
        drawH = basePx
      }

      // 固定在圆环底部居中（考虑 rotation 旋转后的底部位置）
      const bottomAngle = Math.PI / 2 + rotation
      const attachX = centerX + ringRadius * Math.cos(bottomAngle)
      const attachY = centerY + ringRadius * Math.sin(bottomAngle)

      positions[idx] = {
        x: attachX - drawW / 2,
        y: attachY,  // 紧贴圆环外侧底部
        width: drawW,
        height: drawH,
        size: Math.max(drawW, drawH),
        rotate: 0,  // 吊坠不旋转
        zIndex: 5,  // 吊坠在最上层
        isPendant: true
      }
    }

    this.setData({ beadPositions: positions, ringRadius, centerX, centerY, isClosedCircle }, () => {
      wx.nextTick(() => this._updateRingRect())
    })
  },

  // 更新筛选分类
  updateFilteredCategories() {
    const filtered = this.data.categories.filter(c => c.type === this.data.activeType)
    this.setData({ filteredCategories: filtered })
  },

  // 更新是否有真实珠子状态（控制阴影圆环显示）
  updateHasAnyBead() {
    const hasAnyBead = this.data.bracelet.some(b => b.materialId)
    if (this.data.hasAnyBead !== hasAnyBead) {
      this.setData({ hasAnyBead })
    }
  },

  initEmptyBracelet() {
    const bracelet = []
    for (let i = 0; i < DEFAULT_BEAD_COUNT; i++) {
      bracelet.push({
        materialId: '', name: '空位', price: 0,
        color: '#E8E0D8', image: '', type: ''
      })
    }
    this.setData({ bracelet }, () => {
      this.computeBeadPositions()
      this.updateHasAnyBead()
    })
    this.calcPrice()
    this.calcBeadTotalMm()
  },

  async loadDesign(designId) {
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageDesigns',
        data: { action: 'detail', _id: designId }
      })
      const design = res.result
      if (design) {
        // 兼容旧数据：为没有 beadMm 的珠子补充默认值
        const beads = (design.beads || []).map(b => ({
          ...b,
          beadMm: b.beadMm || parseFloat((b.specs && b.specs.size) || 8)
        }))
        // 将已保存设计中珠子的 cloud:// 图片 URL 转换为临时 HTTP URL
        await this._resolveCloudImages(beads)
        this.setData({
          bracelet: beads,
          beadCount: design.beads.length,
          totalPrice: design.totalPrice || 0,
          wristSize: design.wristSize || 16,
          designName: design.name || ''
        }, () => {
          this.computeBeadPositions()
          this.updateHasAnyBead()
        })
        this.calcBeadTotalMm()
        // 预加载珠子图片到本地缓存
        this._preloadBeadImages(beads)
      }
    } catch (e) {
      console.error('加载设计失败', e)
    }
  },

  // 复刻案例：加载珠子到画布，但不关联原设计ID（保存时作为新设计）
  async loadDesignForCopy(designId) {
    wx.showLoading({ title: '加载案例中...' })
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageDesigns',
        data: { action: 'detail', _id: designId }
      })
      const design = res.result
      if (design) {
        const beads = (design.beads || []).map(b => ({
          ...b,
          beadMm: b.beadMm || parseFloat((b.specs && b.specs.size) || 8),
          beadPx: b.beadPx || this.getBeadSizePx(b.specs && b.specs.size)
        }))
        await this._resolveCloudImages(beads)
        this.setData({
          bracelet: beads,
          beadCount: design.beads.length,
          totalPrice: design.totalPrice || 0,
          wristSize: design.wristSize || 16,
          designName: '',
          designId: '' // 不关联原设计，保存时作为新设计
        }, () => {
          this.computeBeadPositions()
          this.updateHasAnyBead()
        })
        this.calcBeadTotalMm()
        // 预加载珠子图片到本地缓存
        this._preloadBeadImages(beads)
        wx.hideLoading()
        wx.showToast({ title: '已加载案例，可修改后保存', icon: 'none' })
      } else {
        wx.hideLoading()
      }
    } catch (e) {
      wx.hideLoading()
      console.error('加载案例失败', e)
      wx.showToast({ title: '加载案例失败', icon: 'none' })
    }
  },

  async loadCategories() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageMaterials',
        data: { action: 'categories', data: {} }
      })
      const categories = res.result || []
      this.setData({ categories })
      this.updateFilteredCategories()
      if (categories.length) {
        const firstBead = categories.find(c => c.type === 'bead')
        if (firstBead) {
          this.setData({ activeCategory: firstBead.name })
          this.loadMaterials() // 改为按 type 加载
        }
      }
    } catch (e) {
      console.error('加载分类失败', e)
    }
  },

  onSwitchType(e) {
    const type = e.currentTarget.dataset.type
    this.setData({ activeType: type, selectedSizes: [] })
    this.updateFilteredCategories()
    const filtered = this.data.filteredCategories
    if (filtered.length) {
      this.setData({ activeCategory: filtered[0].name })
      this.loadMaterials() // 改为按 type 加载
    } else {
      this.setData({ materialList: [], activeCategory: '', allMaterials: [], filteredMaterialList: [], availableSizes: [] })
    }
  },

  onSwitchCategory(e) {
    const name = e.currentTarget.dataset.name
    this.setData({ activeCategory: name })
    // 客户端过滤，无需重新请求服务器
    this.filterMaterialsByCategory(name)
  },

  // 批量将 cloud:// 图片 URL 转换为临时 HTTP URL（仅用于前端显示）
  // 原始 cloud:// URL 保存到 cloudImage 字段，image 字段改为临时 https 链接供 <image> 显示
  // 保存设计时需用 cloudImage 还原 image 字段，避免临时链接入库
  async _resolveCloudImages(list, imageField = 'image') {
    const cloudItems = []
    list.forEach((item, idx) => {
      if (item[imageField] && String(item[imageField]).startsWith('cloud://')) {
        cloudItems.push({ idx, fileID: item[imageField] })
      }
    })
    if (!cloudItems.length) return

    try {
      // wx.cloud.getTempFileURL 每次最多 50 个
      for (let i = 0; i < cloudItems.length; i += 50) {
        const batch = cloudItems.slice(i, i + 50)
        const res = await wx.cloud.getTempFileURL({
          fileList: batch.map(b => b.fileID)
        })
        if (res.fileList) {
          res.fileList.forEach(f => {
            if (f.status === 0 && f.tempFileURL) {
              const match = batch.find(b => b.fileID === f.fileID)
              if (match) {
                // 保留原始 cloud:// URL 到 cloudImage，image 改为临时 https 链接
                list[match.idx].cloudImage = list[match.idx][imageField]
                list[match.idx][imageField] = f.tempFileURL
              }
            }
          })
        }
      }
    } catch (e) {
      console.error('cloud://图片URL转换失败', e)
    }
  },

  // 按 type 加载所有素材，不再按 category 名称筛选
  async loadMaterials() {
    this.setData({ loading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageMaterials',
        data: { action: 'list', data: { type: this.data.activeType, pageSize: 100 } }
      })
      const list = res.result.list || []
      // 预计算颜色hex
      list.forEach(m => {
        m.colorHex = (m.specs && m.specs.color) ? this.getColorHex(m.specs.color) : '#E8E0D8'
      })
      // 将 cloud:// 图片 URL 转为临时 HTTP URL
      await this._resolveCloudImages(list)
      this.setData({ allMaterials: list, loading: false, filteredMaterialList: list })
      // 收集当前素材列表中所有可选尺寸
      this._updateAvailableSizes(list)
      // 初始按当前分类过滤显示
      this.filterMaterialsByCategory(this.data.activeCategory)
    } catch (e) {
      console.error('加载素材失败', e)
      this.setData({ loading: false })
    }
  },

  // 客户端按分类过滤素材（叠加尺寸筛选 + 搜索）
  filterMaterialsByCategory(categoryName) {
    const { allMaterials, searchKeyword, selectedSizes } = this.data
    let list = allMaterials
    if (categoryName) {
      list = list.filter(m => m.category === categoryName)
    }
    // 尺寸筛选：多选时显示所有符合任一尺寸的素材
    if (selectedSizes.length > 0) {
      list = list.filter(m => {
        const size = m.specs && m.specs.size
        return size && selectedSizes.includes(Number(size))
      })
    }
    // 搜索过滤
    if (searchKeyword) {
      const kw = searchKeyword.toLowerCase()
      list = list.filter(m =>
        (m.name && m.name.toLowerCase().includes(kw)) ||
        (m.category && m.category.toLowerCase().includes(kw)) ||
        (m.specs && m.specs.size && String(m.specs.size).includes(kw))
      )
    }
    this.setData({ materialList: list, filteredMaterialList: list })
  },

  // 收集素材列表中所有可选尺寸（去重排序）
  _updateAvailableSizes(materials) {
    const sizeSet = new Set()
    materials.forEach(m => {
      if (m.specs && m.specs.size) {
        sizeSet.add(Number(m.specs.size))
      }
    })
    const availableSizes = [...sizeSet].sort((a, b) => a - b)
    // 清除已选但不再可选的尺寸
    const selectedSizes = this.data.selectedSizes.filter(s => sizeSet.has(s))
    this.setData({ availableSizes, selectedSizes })
  },

  // 切换尺寸筛选（多选）
  onToggleSize(e) {
    const size = Number(e.currentTarget.dataset.size)
    let { selectedSizes } = this.data
    const idx = selectedSizes.indexOf(size)
    if (idx >= 0) {
      selectedSizes.splice(idx, 1)
    } else {
      selectedSizes.push(size)
      selectedSizes.sort((a, b) => a - b)
    }
    this.setData({ selectedSizes: [...selectedSizes] })
    this.filterMaterialsByCategory(this.data.activeCategory)
  },

  // 搜索输入
  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value })
    this.filterMaterialsByCategory(this.data.activeCategory)
  },

  // 切换抽屉
  toggleDrawer() {
    this.setData({ drawerOpen: !this.data.drawerOpen })
  },

  // 使用须知
  onShowNotice() {
    this.setData({ showNotice: true })
  },

  onCloseNotice() {
    this.setData({ showNotice: false })
  },

  getBeadSizePx(sizeStr) {
    const size = parseFloat(sizeStr) || 8
    // 所有类型统一：8mm=32px, 每增2mm加8px
    return Math.round(32 + (size - 8) * 4)
  },

  onTapMaterial(e) {
    const material = e.currentTarget.dataset.item
    const bracelet = [...this.data.bracelet]
    let editingIndex = this.data.editingIndex

    const beadMm = parseFloat((material.specs && material.specs.size) || 8)
    // trackLen: 轨道占用长度(mm)，pendant 默认0不占轨道
    const trackLen = material.type === 'pendant'
      ? 0
      : (parseFloat(material.specs && material.specs.trackLen) || beadMm)
    const beadPx = trackLen * PX_PER_MM
    const imgW = parseInt(material.specs && material.specs.imgW) || 0
    const imgH = parseInt(material.specs && material.specs.imgH) || 0
    const wristMm = this.data.wristSize * 10

    // 严格超限拦截：总轨道长度 > 目标手围 即禁止添加（pendant 不占轨道）
    if (editingIndex >= 0 && editingIndex < bracelet.length) {
      const oldBead = bracelet[editingIndex]
      const currentTotal = this.data.bracelet.reduce((s, b) => {
        return s + (b.materialId && b.type !== 'pendant' ? (b.trackLen || b.beadMm || 8) : 0)
      }, 0)
      const oldTrackLen = oldBead.materialId && oldBead.type !== 'pendant' ? (oldBead.trackLen || oldBead.beadMm || 8) : 0
      if (currentTotal - oldTrackLen + trackLen > wristMm) {
        wx.showToast({ title: '已超出手围上限！请减少珠子或换小尺寸珠子', icon: 'none' })
        return
      }
    } else {
      const currentTotal = this.data.bracelet.reduce((s, b) => {
        return s + (b.materialId && b.type !== 'pendant' ? (b.trackLen || b.beadMm || 8) : 0)
      }, 0)
      if (currentTotal + trackLen > wristMm) {
        wx.showToast({ title: '已超出手围上限！请减少珠子或换小尺寸珠子', icon: 'none' })
        return
      }
    }

    const beadData = {
      materialId: material._id,
      name: material.name,
      price: material.price,
      color: material.specs && material.specs.color ? this.getColorHex(material.specs.color) : '#C4973B',
      image: material.image || '',
      cloudImage: material.cloudImage || '',
      type: material.type,
      beadPx,
      beadMm,
      trackLen,
      imgW,
      imgH
    }

    if (editingIndex >= 0 && editingIndex < bracelet.length) {
      bracelet[editingIndex] = beadData
      let nextEmpty = -1
      for (let i = editingIndex + 1; i < bracelet.length; i++) {
        if (!bracelet[i].materialId) { nextEmpty = i; break }
      }
      if (nextEmpty === -1) {
        for (let i = 0; i < editingIndex; i++) {
          if (!bracelet[i].materialId) { nextEmpty = i; break }
        }
      }
      editingIndex = nextEmpty
    } else {
      const emptyIndex = bracelet.findIndex(b => !b.materialId)
      if (emptyIndex >= 0) {
        bracelet[emptyIndex] = beadData
        editingIndex = emptyIndex + 1 < bracelet.length ? emptyIndex + 1 : -1
      }
    }

    this.setData({ bracelet, editingIndex }, () => {
      this.computeBeadPositions()
      this.updateHasAnyBead()
    })
    this.calcPrice()
    this.calcBeadTotalMm()
    // 预加载新添加的珠子图片
    if (material.image) {
      this._preloadBeadImages([{ materialId: material._id, image: material.image }])
    }
  },

  // 开始触摸（仅双指缩放）
  onTouchStartRotate(e) {
    if (e.touches.length >= 2) {
      // 双指：画布视觉缩放
      const dx = e.touches[0].clientX - e.touches[1].clientX
      const dy = e.touches[0].clientY - e.touches[1].clientY
      this._pinchStartDist = Math.sqrt(dx * dx + dy * dy)
      this._pinchBaseScale = this.data.canvasScale
      this._touchMode = 'pinch'
    }
  },

  // 触摸移动（仅双指缩放）
  onTouchMoveRotate(e) {
    if (e.touches.length >= 2) {
      // 双指：画布视觉缩放（CSS transform，不改变内部坐标）
      if (!this._pinchStartDist) {
        const dx = e.touches[0].clientX - e.touches[1].clientX
        const dy = e.touches[0].clientY - e.touches[1].clientY
        this._pinchStartDist = Math.sqrt(dx * dx + dy * dy)
        this._pinchBaseScale = this.data.canvasScale
      }
      const dx = e.touches[0].clientX - e.touches[1].clientX
      const dy = e.touches[0].clientY - e.touches[1].clientY
      const dist = Math.sqrt(dx * dx + dy * dy)
      let newScale = this._pinchBaseScale * (dist / this._pinchStartDist)
      newScale = Math.min(2.5, Math.max(0.4, newScale))
      this.setData({ canvasScale: newScale })
    }
  },

  // 触摸结束
  onTouchEndRotate() {
    this._touchMode = undefined
    this._pinchStartDist = undefined
    wx.nextTick(() => {
      this._updateRingRect()
      this._updateTrashRect()
    })
  },

  // 向左旋转一步
  onRotateLeft() {
    const step = (2 * Math.PI) / this.data.bracelet.length
    this.setData({ rotation: this.data.rotation - step })
    this.computeBeadPositions()
  },

  // 向右旋转一步
  onRotateRight() {
    const step = (2 * Math.PI) / this.data.bracelet.length
    this.setData({ rotation: this.data.rotation + step })
    this.computeBeadPositions()
  },

  // 切换自动旋转
  toggleAutoRotate() {
    const autoRotate = !this.data.autoRotate
    this.setData({ autoRotate })
    if (autoRotate) {
      this.startAutoRotate()
    } else {
      this.stopAutoRotate()
    }
  },

  startAutoRotate() {
    this.stopAutoRotate() // 确保不重复
    this._autoTimer = setInterval(() => {
      const rotation = this.data.rotation + 0.015
      this.setData({ rotation })
      this.computeBeadPositions()
    }, 30)
  },

  stopAutoRotate() {
    if (this._autoTimer) {
      clearInterval(this._autoTimer)
      this._autoTimer = null
    }
  },

  // 获取预览环容器和垃圾桶区域在页面中的位置
  _updateRingRect() {
    const query = wx.createSelectorQuery().in(this)
    query.select('.preview-ring').boundingClientRect(rect => {
      if (rect) this._ringRect = rect
    }).exec()
    this._updateTrashRect()
  },

  // 获取垃圾桶区域位置
  _updateTrashRect() {
    const query = wx.createSelectorQuery().in(this)
    query.select('.trash-zone').boundingClientRect(rect => {
      if (rect) this._trashRect = rect
    }).exec()
  },

  // 判断触摸点是否在垃圾桶区域内
  _isOverTrash(clientX, clientY) {
    const t = this._trashRect
    if (!t) return false
    return clientX >= t.left && clientX <= t.right &&
           clientY >= t.top && clientY <= t.bottom
  },

  // 开始拖拽
  onTouchStartBead(e) {
    const index = e.currentTarget.dataset.index
    const bead = this.data.bracelet[index]
    if (!bead.materialId) return // 空位不可拖拽

    const touch = e.touches[0]
    const rect = this._ringRect
    if (!rect) return

    // 记录触摸起始位置，用于区分点击和拖拽
    this._beadTouchStartX = touch.clientX
    this._beadTouchStartY = touch.clientY
    this.setData({
      dragIndex: index,
      isDragging: true,
      dragPosition: {
        x: (touch.clientX - rect.left) / this.data.canvasScale - 16,
        y: (touch.clientY - rect.top) / this.data.canvasScale - 16
      }
    }, () => {
      // 拖拽开始后更新垃圾桶区域位置（元素此时才显示）
      wx.nextTick(() => this._updateTrashRect())
    })
  },

  // 拖拽中
  onTouchMoveBead(e) {
    if (!this.data.isDragging) return
    const touch = e.touches[0]
    const rect = this._ringRect
    if (!rect) return

    // 检测是否悬停在垃圾桶区域
    const trashHover = this._isOverTrash(touch.clientX, touch.clientY)

    const update = {
      dragPosition: {
        x: (touch.clientX - rect.left) / this.data.canvasScale - 16,
        y: (touch.clientY - rect.top) / this.data.canvasScale - 16
      },
      trashHover
    }
    // 首次拖拽移动时清除选中状态
    if (this.data.editingIndex >= 0) {
      update.editingIndex = -1
    }
    this.setData(update)
  },

  // 结束拖拽：垃圾桶删除 / 弧长定位精准换位 / 点击选中
  onTouchEndBead(e) {
    if (!this.data.isDragging) return
    const { dragIndex, bracelet, trashHover } = this.data

    const touch = e.changedTouches[0]
    // 检测是否为点击（手指几乎没动）：移动 < 10px 视为点击
    if (this._beadTouchStartX !== undefined) {
      const dx = touch.clientX - this._beadTouchStartX
      const dy = touch.clientY - this._beadTouchStartY
      if (Math.sqrt(dx * dx + dy * dy) < 10) {
        this._beadTouchStartX = undefined
        this._beadTouchStartY = undefined
        this.setData({ isDragging: false, dragIndex: -1, trashHover: false })
        return // 让 tap 事件处理选中
      }
    }

    // 拖入垃圾桶 → 删除珠子
    if (trashHover) {
      const newBracelet = [...bracelet]
      newBracelet[dragIndex] = {
        materialId: '', name: '空位', price: 0,
        color: '#E8E0D8', image: '', type: ''
      }
      this.setData({ bracelet: newBracelet, isDragging: false, dragIndex: -1, trashHover: false }, () => {
        this.computeBeadPositions()
        this.updateHasAnyBead()
        this.calcPrice()
        this.calcBeadTotalMm()
      })
      wx.showToast({ title: '已删除', icon: 'none', duration: 800 })
      this._beadTouchStartX = undefined
      this._beadTouchStartY = undefined
      return
    }

    // 松手在画布上 → 基于弧长定位精准换位
    // pendant 类型不参与圆环换位，松手回到原位
    const movedBeadType = bracelet[dragIndex] ? bracelet[dragIndex].type : ''
    if (movedBeadType === 'pendant') {
      this.setData({ isDragging: false, dragIndex: -1, trashHover: false })
      this._beadTouchStartX = undefined
      this._beadTouchStartY = undefined
      return
    }

    const rect = this._ringRect
    if (!rect) {
      this.setData({ isDragging: false, dragIndex: -1, trashHover: false })
      this._beadTouchStartX = undefined
      this._beadTouchStartY = undefined
      return
    }

    const scale = this.data.canvasScale
    const relX = (touch.clientX - rect.left) / scale
    const relY = (touch.clientY - rect.top) / scale
    const cx = this.data.ringRadius + 40
    const cy = this.data.ringRadius + 40
    const dx = relX - cx
    const dy = relY - cy
    const dropAngle = Math.atan2(dy, dx)

    // 先从数组中取出被拖拽的珠子
    const newBracelet = [...bracelet]
    const [movedBead] = newBracelet.splice(dragIndex, 1)

    // 基于弧长位置计算插入点
    const targetIndex = this._findDropIndexByArc(newBracelet, dropAngle)

    newBracelet.splice(targetIndex, 0, movedBead)

    this.setData({ bracelet: newBracelet, isDragging: false, dragIndex: -1, trashHover: false }, () => {
      this.computeBeadPositions()
      this.updateHasAnyBead()
      this.calcPrice()
      this.calcBeadTotalMm()
    })

    this._beadTouchStartX = undefined
    this._beadTouchStartY = undefined
  },

  // 基于弧长位置精准计算拖放插入点
  // braceletArr: 已移除被拖拽珠子后的数组
  // dropAngle: 松手位置相对于圆心的角度（弧度）
  _findDropIndexByArc(braceletArr, dropAngle) {
    const { ringRadius, rotation } = this.data
    const circumference = 2 * Math.PI * ringRadius

    // 将松手角度转换为圆环上的弧长位置
    let dropArc = (dropAngle + Math.PI / 2 - rotation) * ringRadius
    dropArc = ((dropArc % circumference) + circumference) % circumference

    // 计算所有参与圆环排列的珠子（排除 pendant）的弧长中心位置
    const realBeads = []
    let arcPos = 0
    for (let i = 0; i < braceletArr.length; i++) {
      const b = braceletArr[i]
      if (b.materialId && b.type !== 'pendant') {
        const trackPx = (b.trackLen || b.beadMm || 8) * PX_PER_MM
        realBeads.push({
          arrayIdx: i,
          arcCenter: arcPos + trackPx / 2
        })
        arcPos += trackPx
      }
    }

    // 无其他真实珠子，插入到数组起始位置
    if (realBeads.length === 0) return 0

    // 找到松手弧长落在哪两个相邻真实珠子之间
    let insertPos = realBeads.length // 默认：最后一个珠子之后
    for (let i = 0; i < realBeads.length; i++) {
      if (dropArc < realBeads[i].arcCenter) {
        insertPos = i
        break
      }
    }

    // 将插入位置映射回数组索引
    if (insertPos >= realBeads.length) {
      return realBeads[realBeads.length - 1].arrayIdx + 1
    }
    return realBeads[insertPos].arrayIdx
  },

  onTapBead(e) {
    const index = e.currentTarget.dataset.index
    this.setData({ editingIndex: index })
  },

  onRemoveBead() {
    const { editingIndex, bracelet } = this.data
    if (editingIndex < 0) return
    bracelet[editingIndex] = {
      materialId: '', name: '空位', price: 0,
      color: '#E8E0D8', image: '', type: ''
    }
    this.setData({ bracelet, editingIndex: -1 }, () => {
      this.updateHasAnyBead()
    })
    this.calcPrice()
    this.calcBeadTotalMm()
  },

  onClearBracelet() {
    wx.showModal({
      title: '确认清空',
      content: '是否清空当前手串设计？',
      success: (res) => {
        if (res.confirm) {
          this.initEmptyBracelet()
          this.setData({ editingIndex: -1, totalPrice: 0 })
        }
      }
    })
  },

  calcPrice() {
    const total = this.data.bracelet.reduce((sum, b) => sum + (b.price || 0), 0)
    this.setData({ totalPrice: total })
  },

  // 计算当前手串总周长（mm），超目标即拦截
  calcBeadTotalMm() {
    const totalMm = this.data.bracelet.reduce((sum, b) => {
      // pendant 不占轨道，不计入总周长；其他类型使用 trackLen
      if (!b.materialId || b.type === 'pendant') return sum
      return sum + (b.trackLen || b.beadMm || 8)
    }, 0)
    const wristMm = this.data.wristSize * 10
    const isUnderTarget = totalMm > 0 && totalMm < wristMm
    const isOverLimit = totalMm > wristMm
    const beadTotalCm = (totalMm / 10).toFixed(1)
    this.setData({ beadTotalMm: totalMm, beadTotalCm, isOverLimit, isUnderTarget })
  },

  getColorHex(colorName) {
    const map = {
      '紫色': '#9B72CF', '粉色': '#E8A0BF', '白色': '#F0EDE8',
      '黄色': '#E8C84A', '茶色': '#8B6F4E', '金色': '#C4973B',
      '红色': '#C44B4B', '蓝色': '#4A7FB5', '绿色': '#3B8C6E',
      '酒红': '#8B2252', '银色': '#C0C0C0', '彩虹': '#A8D8EA',
      '蓝白': '#B8D4E3', '黑色': '#3D3D3D', '橙色': '#E8944A'
    }
    return map[colorName] || '#C4973B'
  },

  // 珠子图片缓存：{ imageSrc => Image对象 }，供 _generatePreviewImage 复用
  _beadImageCache: {},

  // 预加载珠子图片到缓存（不依赖 canvas 实例，用通用 wx.getImageInfo 触发下载）
  async _preloadBeadImages(beads) {
    if (!beads || !beads.length) return
    const cache = this._beadImageCache
    if (!cache) return
    const urls = []
    for (const b of beads) {
      if (b && b.materialId && b.image && !cache[b.image]) {
        urls.push(b.image)
      }
    }
    if (!urls.length) return
    // 用 getImageInfo 触发微信内部 HTTP 缓存，后续 createImage 可秒加载
    const promises = urls.map(url => new Promise(resolve => {
      wx.getImageInfo({
        src: url,
        success: () => { cache[url] = true },
        fail: () => { /* 忽略失败，生成时再降级 */ }
      })
      // 不等回调，getImageInfo 触发下载后即走缓存
      resolve()
    }))
    await Promise.all(promises)
  },


   // 生成手串预览缩略图：用真实珠子图片绘制，上传云存储，返回 cloud:// URL
   _generatePreviewImage() {
    const self = this
    return new Promise((resolve) => {
      const query = wx.createSelectorQuery()
      query.select('#previewCanvas')
        .fields({ node: true, size: true })
        .exec(async (res) => {
          if (!res[0] || !res[0].node) {
            console.warn('Canvas节点获取失败，跳过预览图生成')
            resolve('')
            return
          }
          const canvas = res[0].node
          const ctx = canvas.getContext('2d')
          const cache = self._beadImageCache || {}

          const CANVAS_SIZE = 300
          const dpr = wx.getWindowInfo().pixelRatio
          canvas.width = CANVAS_SIZE * dpr
          canvas.height = CANVAS_SIZE * dpr
          ctx.scale(dpr, dpr)

          // 透明背景（不填充白色，PNG 保留透明通道）

          const { bracelet, beadPositions, ringRadius, centerX, centerY } = this.data
          if (!ringRadius || ringRadius <= 0) {
            this._exportCanvasImage(canvas).then(resolve)
            return
          }

          // 缩放比
          const layoutSize = ringRadius * 2 + 80
          const scale = (CANVAS_SIZE - 20) / layoutSize
          const offsetX = 10 / scale
          const offsetY = 10 / scale

          // 画手串线
          ctx.save()
          ctx.scale(scale, scale)
          ctx.translate(offsetX, offsetY)
          ctx.beginPath()
          ctx.arc(centerX, centerY, ringRadius, 0, Math.PI * 2)
          ctx.strokeStyle = '#E0D8CE'
          ctx.lineWidth = 3
          ctx.stroke()

          // 预加载所有珠子图片（优先复用缓存，未缓存则用 createImage 加载）
          const beadImages = []
          for (let i = 0; i < bracelet.length; i++) {
            beadImages.push(null)
          }

          const loadPromises = []
          for (let i = 0; i < bracelet.length; i++) {
            const bead = bracelet[i]
            const pos = beadPositions[i]
            if (!bead.materialId || !pos || pos.size <= 0) continue

            // 使用 HTTPS 临时 URL（cloud:// 协议 Canvas createImage 不支持）
            if (bead.image) {
              const imgSrc = bead.image
              const p = new Promise((imgResolve) => {
                const img = canvas.createImage()
                img.onload = () => {
                  beadImages[i] = img
                  cache[imgSrc] = img
                  imgResolve()
                }
                img.onerror = () => {
                  beadImages[i] = null
                  imgResolve()
                }
                img.src = imgSrc
              })
              // 5秒超时，防止图片加载卡住
              const timeout = new Promise(resolve => {
                setTimeout(() => { resolve() }, 5000)
              })
              loadPromises.push(Promise.race([p, timeout]))
            }
          }

          await Promise.all(loadPromises)

          // 绘制珠子（按类型区分绘制方式）
          for (let i = 0; i < bracelet.length; i++) {
            const bead = bracelet[i]
            const pos = beadPositions[i]
            if (!bead.materialId || !pos || pos.size <= 0) continue

            const drawW = pos.width || pos.size
            const drawH = pos.height || pos.size
            const cx = pos.x + drawW / 2
            const cy = pos.y + drawH / 2

            if (pos.isPendant) {
              // === 吊坠：不旋转，按真实比例绘制 ===
              if (beadImages[i]) {
                const img = beadImages[i]
                const imgW = img.width || drawW
                const imgH = img.height || drawH
                const ratio = Math.min(drawW / imgW, drawH / imgH)
                const w = imgW * ratio
                const h = imgH * ratio
                ctx.drawImage(img, pos.x + (drawW - w) / 2, pos.y + (drawH - h) / 2, w, h)
              }
              // 吊坠无图片时不绘制颜色圆（吊坠必须有图片）
            } else if (bead.type === 'ornament') {
              // === 配饰：按真实比例绘制，随轨道角度旋转 ===
              ctx.save()
              ctx.translate(cx, cy)
              ctx.rotate(pos.rotate * Math.PI / 180)
              if (beadImages[i]) {
                const img = beadImages[i]
                const imgW = img.width || drawW
                const imgH = img.height || drawH
                const ratio = Math.min(drawW / imgW, drawH / imgH)
                const w = imgW * ratio
                const h = imgH * ratio
                ctx.drawImage(img, -w / 2, -h / 2, w, h)
              }
              ctx.restore()
            } else if (bead.type === 'spacer') {
              // === 隔片：沿切线方向旋转，保持异形透明 ===
              ctx.save()
              ctx.translate(cx, cy)
              ctx.rotate(pos.rotate * Math.PI / 180)
              if (beadImages[i]) {
                const img = beadImages[i]
                const imgW = img.width || drawW
                const imgH = img.height || drawH
                const ratio = Math.min(drawW / imgW, drawH / imgH)
                const w = imgW * ratio
                const h = imgH * ratio
                ctx.drawImage(img, -w / 2, -h / 2, w, h)
              }
              ctx.restore()
              // 隔片无图片时不绘制颜色圆
            } else {
              // === 圆珠bead：正常绘制 ===
              if (beadImages[i]) {
                const img = beadImages[i]
                const imgW = img.width || drawW
                const imgH = img.height || drawH
                const ratio = Math.min(drawW / imgW, drawH / imgH)
                const w = imgW * ratio
                const h = imgH * ratio
                ctx.drawImage(img, pos.x + (drawW - w) / 2, pos.y + (drawH - h) / 2, w, h)
              } else {
                // 无图片时用颜色圆 + 高光
                const br = drawW / 2
                ctx.beginPath()
                ctx.arc(cx, cy, br, 0, Math.PI * 2)
                ctx.fillStyle = bead.color || '#C4973B'
                ctx.fill()

                const grad = ctx.createRadialGradient(cx - br * 0.3, cy - br * 0.3, 0, cx, cy, br)
                grad.addColorStop(0, 'rgba(255,255,255,0.35)')
                grad.addColorStop(1, 'rgba(255,255,255,0)')
                ctx.beginPath()
                ctx.arc(cx, cy, br, 0, Math.PI * 2)
                ctx.fillStyle = grad
                ctx.fill()
              }
            }
          }

          ctx.restore()

          // 导出并上传
          this._exportCanvasImage(canvas).then(resolve)
        })
    })
  },

// 导出Canvas为图片并上传云存储 → 保留原Gitee上传逻辑
_exportCanvasImage(canvas) {
  return new Promise((resolve) => {
    wx.canvasToTempFilePath({
      canvas: canvas,
      width: canvas.width,
      height: canvas.height,
      destWidth: 300,
      destHeight: 300,
      fileType: 'png',
      success: (tempRes) => {
        const tempPath = tempRes.tempFilePath

        wx.getFileSystemManager().readFile({
          filePath: tempPath,
          encoding: "base64",
          success: (res) => {
            const base64Data = res.data;
            const fileName = "img/" + Date.now() + ".png";

            wx.request({
              url: "https://gitee.com/api/v5/repos/yutian1962539249/img-bed/contents/" + fileName,
              method: "POST",
              header: {
                "Content-Type": "application/json"
              },
              data: {
                access_token: "87144e4a22b77a19befc014b585db430",
                content: base64Data,
                message: "upload design",
                branch: "master"
              },
              success: (result) => {
                try {
                  if (result.statusCode === 201 && result.data.content) {
                    resolve(result.data.content.download_url);
                  } else {
                    resolve("");
                  }
                } catch (e) {
                  resolve("");
                }
              },
              fail: () => resolve("")
            });
          },
          fail: () => resolve("")
        });
      },
      fail: () => resolve("")
    })
  })
},

  onSaveDesign() {
    const hasBead = this.data.bracelet.some(b => b.materialId)
    if (!hasBead) {
      wx.showToast({ title: '请至少选择一颗珠子', icon: 'none' })
      return
    }
    this.setData({ showSaveModal: true })
  },

  async doSaveDesign() {
    const { designName, bracelet, totalPrice, wristSize, designId } = this.data
    if (!designName.trim()) {
      wx.showToast({ title: '请输入设计名称', icon: 'none' })
      return
    }

    wx.showLoading({ title: '保存中...' })
    try {
      // 生成手串预览缩略图
      const previewImage = await this._generatePreviewImage()

      // 保存前还原 image 为原始 cloud:// URL，避免临时 https 链接入库
      const beads = bracelet.map(b => {
        const bead = { ...b }
        if (bead.cloudImage) {
          bead.image = bead.cloudImage
          delete bead.cloudImage
        }
        return bead
      })

      const data = {
        name: designName,
        beads,
        totalPrice,
        wristSize,
        beadCount: bracelet.length,
        previewImage
      }

      if (designId) {
        await wx.cloud.callFunction({
          name: 'manageDesigns',
          data: { action: 'update', _id: designId, data }
        })
      } else {
        await wx.cloud.callFunction({
          name: 'manageDesigns',
          data: { action: 'save', data }
        })
      }

      wx.hideLoading()
      wx.showToast({ title: '保存成功', icon: 'success' })
      this.setData({ showSaveModal: false })
    } catch (e) {
      wx.hideLoading()
      wx.showToast({ title: '保存失败', icon: 'none' })
      console.error(e)
    }
  },

  onInputDesignName(e) {
    this.setData({ designName: e.detail.value })
  },

  onCloseSaveModal() {
    this.setData({ showSaveModal: false })
  },

  async onGoOrder() {
    const hasBead = this.data.bracelet.some(b => b.materialId)
    if (!hasBead) {
      wx.showToast({ title: '请至少选择一颗珠子', icon: 'none' })
      return
    }
    // 生成预览图（如果还没有）
    let previewImage = this.data._lastPreviewImage || ''
    if (!previewImage) {
      wx.showLoading({ title: '准备中...' })
      previewImage = await this._generatePreviewImage()
      wx.hideLoading()
      this.data._lastPreviewImage = previewImage
    }
    const designData = {
      beads: this.data.bracelet,
      totalPrice: this.data.totalPrice,
      wristSize: this.data.wristSize,
      beadCount: this.data.beadCount,
      previewImage
    }
    app.globalData.currentDesign = designData
    wx.navigateTo({ url: '/pages/order/order' })
  },

  onShowSizePicker() {
    this.setData({ showSizePicker: true })
  },

  onSelectSize(e) {
    const size = e.currentTarget.dataset.size
    const beadCount = Math.round(size / 0.8)
    const bracelet = [...this.data.bracelet]
    if (beadCount > bracelet.length) {
      for (let i = bracelet.length; i < beadCount; i++) {
        bracelet.push({ materialId: '', name: '空位', price: 0, color: '#E8E0D8', image: '', type: '' })
      }
    } else if (beadCount < bracelet.length) {
      bracelet.splice(beadCount)
    }
    this.setData({ wristSize: size, beadCount, bracelet, showSizePicker: false }, () => {
      this.computeBeadPositions()
      this.updateHasAnyBead()
      this.calcBeadTotalMm()
    })
    this.calcPrice()
  },

  onCloseSizePicker() {
    this.setData({ showSizePicker: false })
  },

  // 返回上一页或首页
  onGoBack() {
    const pages = getCurrentPages()
    if (pages.length > 1) {
      wx.navigateBack()
    } else {
      wx.switchTab({ url: '/pages/index/index' })
    }
  }
})
