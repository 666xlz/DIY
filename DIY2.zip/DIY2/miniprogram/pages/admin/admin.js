// 素材管理后台
Page({
  data: {
    categories: [],
    materials: [],
    loading: true,
    activeTab: 'materials', // materials / categories
    activeType: 'bead'
  },

  onLoad() {
    this.loadData()
  },

  onShow() {
    this.loadData()
  },

  async loadData() {
    this.setData({ loading: true })
    try {
      // 加载分类
      const catRes = await wx.cloud.callFunction({
        name: 'manageMaterials',
        data: { action: 'categories', data: {} }
      })
      const categories = catRes.result || []

      // 加载素材
      const matRes = await wx.cloud.callFunction({
        name: 'manageMaterials',
        data: { action: 'list', data: { type: this.data.activeType, pageSize: 100 } }
      })
      const materials = matRes.result.list || []
      await this._resolveCloudImages(materials)

      this.setData({ categories, materials, loading: false })
    } catch (e) {
      console.error('加载数据失败', e)
      this.setData({ loading: false })
    }
  },

  // 切换标签
  onSwitchTab(e) {
    this.setData({ activeTab: e.currentTarget.dataset.tab })
  },

  // 切换素材类型
  onSwitchType(e) {
    const type = e.currentTarget.dataset.type
    this.setData({ activeType: type })
    this.loadMaterials(type)
  },

  async loadMaterials(type) {
    this.setData({ loading: true })
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageMaterials',
        data: { action: 'list', data: { type, pageSize: 100 } }
      })
      const materials = res.result.list || []
      await this._resolveCloudImages(materials)
      this.setData({ materials, loading: false })
    } catch (e) {
      this.setData({ loading: false })
    }
  },

  // 新增素材
  onAddMaterial() {
    wx.navigateTo({ url: '/pages/admin/material-edit/material-edit' })
  },

  // 编辑素材
  onEditMaterial(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: '/pages/admin/material-edit/material-edit?id=' + id })
  },

  // 删除素材
  onDeleteMaterial(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '确认删除',
      content: '确定删除此素材？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await wx.cloud.callFunction({
              name: 'manageMaterials',
              data: { action: 'delete', _id: id }
            })
            wx.showToast({ title: '已删除', icon: 'success' })
            this.loadData()
          } catch (e) {
            wx.showToast({ title: '删除失败', icon: 'none' })
          }
        }
      }
    })
  },

  // 初始化数据
  async onInitData() {
    wx.showModal({
      title: '初始化数据',
      content: '将初始化示例分类和素材数据，是否继续？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '初始化中...' })
          try {
            await wx.cloud.callFunction({
              name: 'initData',
              data: { action: 'initCategories' }
            })
            await wx.cloud.callFunction({
              name: 'initData',
              data: { action: 'initMaterials' }
            })
            wx.hideLoading()
            wx.showToast({ title: '初始化成功', icon: 'success' })
            this.loadData()
          } catch (e) {
            wx.hideLoading()
            wx.showToast({ title: '初始化失败', icon: 'none' })
            console.error(e)
          }
        }
      }
    })
  },

  // 批量将 cloud:// 图片 URL 转换为临时 HTTP URL（仅用于前端显示）
  async _resolveCloudImages(list, imageField = 'image') {
    const cloudItems = []
    list.forEach((item, idx) => {
      if (item[imageField] && String(item[imageField]).startsWith('cloud://')) {
        cloudItems.push({ idx, fileID: item[imageField] })
      }
    })
    if (!cloudItems.length) return

    try {
      for (let i = 0; i < cloudItems.length; i += 50) {
        const batch = cloudItems.slice(i, i + 50)
        const res = await wx.cloud.getTempFileURL({
          fileList: batch.map(b => b.fileID)
        })
        if (res.fileList) {
          res.fileList.forEach(f => {
            if (f.status === 0 && f.tempFileURL) {
              const match = batch.find(b => b.fileID === f.fileID)
              if (match) {
                list[match.idx][imageField] = f.tempFileURL
              }
            }
          })
        }
      }
    } catch (e) {
      console.error('cloud://图片URL转换失败', e)
    }
  }
})
