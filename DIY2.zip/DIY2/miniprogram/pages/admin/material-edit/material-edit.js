// 素材编辑页
Page({
  data: {
    _id: '',
    isEdit: false,
    name: '',
    category: '',
    categoryIndex: -1, // picker 需要的索引值
    type: 'bead',
    typeIndex: 0, // picker 需要的索引值
    price: '',
    stock: '',
    image: '',
    fileID: '',
    color: '',
    size: '',
    material: '',
    sort: '1',
    trackLen: '',    // 轨道占用长度(mm)
    imgW: '',        // 图片宽(px)
    imgH: '',        // 图片高(px)
    // 各类型的 trackLen 提示
    trackLenPlaceholder: '如：8（珠子直径）',
    trackLenLabel: '轨道长度(mm)',
    categories: [],
    typeOptions: [
      { value: 'bead', label: '圆珠' },
      { value: 'spacer', label: '隔片' },
      { value: 'ornament', label: '配饰' },
      { value: 'pendant', label: '吊坠' }
    ]
  },

  onLoad(options) {
    this.loadCategories()
    if (options.id) {
      this.setData({ _id: options.id, isEdit: true })
      this.loadMaterial(options.id)
    }
  },

  async loadCategories() {
    try {
      const res = await wx.cloud.callFunction({
        name: 'manageMaterials',
        data: { action: 'categories', data: {} }
      })
      const categories = res.result || []
      const extra = {}
      // 编辑模式下，等分类加载完后修正 categoryIndex
      if (this.data._id && this.data.category && categories.length > 0) {
        extra.categoryIndex = Math.max(0, categories.findIndex(c => c.name === this.data.category))
      }
      this.setData({ categories, ...extra })
    } catch (e) {
      console.error(e)
    }
  },

  async loadMaterial(id) {
    try {
      const db = wx.cloud.database()
      const res = await db.collection('materials').doc(id).get()
      const m = res.data
      // 将 cloud:// 图片 URL 转为临时 https 链接，确保所有用户可见
      let displayImage = m.image || ''
      if (displayImage && String(displayImage).startsWith('cloud://')) {
        try {
          const tmpRes = await wx.cloud.getTempFileURL({ fileList: [displayImage] })
          if (tmpRes.fileList && tmpRes.fileList[0] && tmpRes.fileList[0].status === 0) {
            displayImage = tmpRes.fileList[0].tempFileURL
          }
        } catch (e) {
          console.error('素材图片URL转换失败', e)
        }
      }
      this.setData({
        name: m.name,
        category: m.category,
        categoryIndex: this.data.categories.length > 0
          ? Math.max(0, this.data.categories.findIndex(c => c.name === m.category))
          : -1,
        type: m.type,
        typeIndex: Math.max(0, this.data.typeOptions.findIndex(o => o.value === m.type)),
        price: (m.price / 100).toString(),
        stock: m.stock.toString(),
        image: displayImage,
        fileID: m.image || '',
        color: m.specs ? m.specs.color : '',
        size: m.specs ? m.specs.size : '',
        material: m.specs ? m.specs.material : '',
        sort: m.sort ? m.sort.toString() : '1',
        trackLen: m.specs && m.specs.trackLen ? m.specs.trackLen.toString() : '',
        imgW: m.specs && m.specs.imgW ? m.specs.imgW.toString() : '',
        imgH: m.specs && m.specs.imgH ? m.specs.imgH.toString() : ''
      })
      // 根据类型更新提示
      this._updateTypeHints(m.type)
    } catch (e) {
      console.error(e)
    }
  },

  onInputName(e) { this.setData({ name: e.detail.value }) },
  onInputPrice(e) { this.setData({ price: e.detail.value }) },
  onInputStock(e) { this.setData({ stock: e.detail.value }) },
  onInputColor(e) { this.setData({ color: e.detail.value }) },
  onInputSize(e) { this.setData({ size: e.detail.value }) },
  onInputMaterial(e) { this.setData({ material: e.detail.value }) },
  onInputSort(e) { this.setData({ sort: e.detail.value }) },
  onInputTrackLen(e) { this.setData({ trackLen: e.detail.value }) },
  onInputImgW(e) { this.setData({ imgW: e.detail.value }) },
  onInputImgH(e) { this.setData({ imgH: e.detail.value }) },

  onSwitchType(e) {
    const index = parseInt(e.detail.value)
    const newType = this.data.typeOptions[index].value
    this.setData({ typeIndex: index, type: newType })
    this._updateTypeHints(newType)
  },

  // 根据素材类型更新 trackLen 提示和默认值
  _updateTypeHints(type) {
    const hints = {
      bead: { placeholder: '如：8（珠子直径）', label: '轨道长度(mm)', defaultTrackLen: this.data.size || '' },
      spacer: { placeholder: '如：2（窄间距）', label: '轨道长度(mm)', defaultTrackLen: '2' },
      ornament: { placeholder: '如：10（占用轨道长度）', label: '轨道长度(mm)', defaultTrackLen: this.data.size || '' },
      pendant: { placeholder: '填0（不占轨道）', label: '轨道长度(mm)', defaultTrackLen: '0' }
    }
    const hint = hints[type] || hints.bead
    // 仅在 trackLen 为空时自动填充默认值
    const updates = {
      trackLenPlaceholder: hint.placeholder,
      trackLenLabel: hint.label
    }
    if (!this.data.trackLen && hint.defaultTrackLen) {
      updates.trackLen = hint.defaultTrackLen
    }
    this.setData(updates)
  },

  onSwitchCategory(e) {
    const index = parseInt(e.detail.value)
    this.setData({ category: this.data.categories[index] ? this.data.categories[index].name : '' })
  },
/*
  // 上传图片
  onChooseImage() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: async (res) => {
        const tempPath = res.tempFiles[0].tempFilePath
        this.setData({ image: tempPath })
        // 上传到云存储
        wx.showLoading({ title: '上传中...' })
        try {
          const uploadRes = await wx.cloud.uploadFile({
            cloudPath: 'materials/' + Date.now() + '_' + Math.floor(Math.random() * 1000) + '.jpg',
            filePath: tempPath
          })
          this.setData({ fileID: uploadRes.fileID, image: uploadRes.fileID })
          wx.hideLoading()
          wx.showToast({ title: '上传成功', icon: 'success' })
        } catch (e) {
          wx.hideLoading()
          wx.showToast({ title: '上传失败', icon: 'none' })
          console.error(e)
        }
      }
    })
  },
  */
 //上传图片
  onChooseImage() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: async (res) => {
        const tempPath = res.tempFiles[0].tempFilePath
        this.setData({ image: tempPath })
        // 上传图床
        wx.showLoading({ title: '上传中...' })
        try {
          const imageUrl = await this.uploadToImgBB(tempPath);

          this.setData({ 
            fileID: imageUrl,   // 把图床地址当fileID用
            image: imageUrl 
          })
          wx.hideLoading()
          wx.showToast({ title: '上传成功', icon: 'success' })
        } catch (e) {
          wx.hideLoading()
          wx.showToast({ title: '上传失败', icon: 'none' })
          console.error(e)
        }
      }
    })
  },

 // 已完美替换为 Gitee 上传（和你原来写法完全一致）
uploadToImgBB(tempFilePath) {
  return new Promise((resolve, reject) => {
    // 读取图片转 base64
    wx.getFileSystemManager().readFile({
      filePath: tempFilePath,
      encoding: 'base64',
      success: (res) => {
        const base64Data = res.data;
        const fileName = "img/" + Date.now() + "_" + Math.random().toString(36).slice(2, 8) + ".png";

        // 上传到你的 Gitee 仓库
        wx.request({
          url: "https://gitee.com/api/v5/repos/yutian1962539249/img-bed/contents/" + fileName,
          method: "POST",
          header: {
            "Content-Type": "application/json"
          },
          data: {
            access_token: "87144e4a22b77a19befc014b585db430",
            content: base64Data,
            message: "upload image",
            branch: "master"
          },
          success: (result) => {
            try {
              if (result.statusCode === 201 && result.data?.content?.download_url) {
                resolve(result.data.content.download_url);
              } else {
                reject("上传失败：" + JSON.stringify(result.data));
              }
            } catch (e) {
              reject("解析失败");
            }
          },
          fail: () => {
            reject("网络错误");
          }
        });
      },
      fail: () => {
        reject("读取图片失败");
      }
    });
  });
},

  // 保存
  async onSave() {
    const { name, category, type, price, stock, color, size, material, sort, fileID, _id, trackLen, imgW, imgH } = this.data
    if (!name.trim()) { wx.showToast({ title: '请输入名称', icon: 'none' }); return }
    if (!category) { wx.showToast({ title: '请选择分类', icon: 'none' }); return }
    if (!price || isNaN(parseFloat(price))) { wx.showToast({ title: '请输入正确价格', icon: 'none' }); return }

    const data = {
      name,
      category,
      type,
      price: Math.round(parseFloat(price) * 100),
      stock: parseInt(stock) || 0,
      image: fileID || '',
      specs: {
        color,
        size,
        material,
        trackLen: parseFloat(trackLen) || 0,
        imgW: parseInt(imgW) || 0,
        imgH: parseInt(imgH) || 0
      },
      sort: parseInt(sort) || 1
    }

    wx.showLoading({ title: '保存中...' })
    try {
      if (_id) {
        await wx.cloud.callFunction({
          name: 'manageMaterials',
          data: { action: 'update', _id, data }
        })
      } else {
        await wx.cloud.callFunction({
          name: 'manageMaterials',
          data: { action: 'add', data }
        })
      }
      wx.hideLoading()
      wx.showToast({ title: '保存成功', icon: 'success' })
      setTimeout(() => wx.navigateBack(), 1000)
    } catch (e) {
      wx.hideLoading()
      wx.showToast({ title: '保存失败', icon: 'none' })
      console.error(e)
    }
  }
})
